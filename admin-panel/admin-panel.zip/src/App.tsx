import React, { useEffect } from "react";
import { Authenticated, Refine, useLogout } from "@refinedev/core";
import { RefineKbar, RefineKbarProvider } from "@refinedev/kbar";
import {
  ErrorComponent,
  RefineSnackbarProvider,
  useNotificationProvider,
} from "@refinedev/mui";
import { SnackbarProvider } from "notistack";
import CssBaseline from "@mui/material/CssBaseline";
import GlobalStyles from "@mui/material/GlobalStyles";
import routerProvider, {
  CatchAllNavigate,
  DocumentTitleHandler,
  NavigateToResource,
  UnsavedChangesNotifier,
} from "@refinedev/react-router";
import dataProvider from "@refinedev/simple-rest";
import { BrowserRouter, Outlet, Route, Routes, Navigate } from "react-router-dom";
import { useSnackbar } from "notistack";

import { authProvider } from "./authProvider";
import Box from "@mui/material/Box";
import { ColorModeContextProvider } from "./contexts/color-mode";
import { LeftSider } from "./components/LeftSider";
import { Login } from "./pages/login";
import { Register } from "./pages/register";
import { ForgotPassword } from "./pages/forgotPassword";
import { ResetPasswordPage } from "./pages/resetPassword";
import { Dashboard } from "./pages/dashboard";
import { MandiManagerOperations } from "./pages/mandiManagerOperations";
import { MandiManagerApprovals } from "./pages/mandiManagerApprovals";
import { MandiManagerStaff } from "./pages/mandiManagerStaff";
import { MandiManagerReports } from "./pages/mandiManagerReports";
import { MandiManagerManagement } from "./pages/mandiManagerManagement";
import { Orgs } from "./pages/orgs";
import { Mandis } from "./pages/mandis";
import { AdminUsers } from "./pages/adminUsers";
import { TraderApprovals } from "./pages/traderApprovals";
import { Traders } from "./pages/traders";
import { Farmers } from "./pages/farmers";
import { FarmerApprovals } from "./pages/farmerApprovals";
import { MandiCoverage } from "./pages/mandiCoverage";
import { MandiPrices } from "./pages/mandiPrices";
import { Reports } from "./pages/reports";
import TwoFactorSettings from "./pages/systemSecurity/twoFactor";
import StepUpPoliciesPage from "./pages/systemSecurity/stepupPolicies";
import SecuritySwitchesPage from "./pages/systemSecurity/securitySwitches";
import SystemSecurityPage from "./pages/systemSecurity";
import SystemCapacityControlPage from "./pages/systemCapacityControl";
import { Commodities } from "./pages/commodities";
import { CommodityProducts } from "./pages/commodityProducts";
import { MandiCommodityProductsMasters } from "./pages/mandiCommodityProductsMasters";
import { MandiFacilities } from "./pages/mandiFacilities";
import { MandiGates } from "./pages/mandiGates";
import { MandiHoursTemplates } from "./pages/mandiHoursTemplates";
import { GateEntryReasons } from "./pages/gateEntryReasons";
import { GateVehicleTypes } from "./pages/gateVehicleTypes";
import { AuctionMethods } from "./pages/auctionMethods";
import { AuctionRounds } from "./pages/auctionRounds";
import { AuctionPolicies } from "./pages/auctionPolicies";
import { AuctionPolicySettingsPage } from "./pages/auctionPolicySettings";
import { AuctionSettings } from "./pages/auctionSettings";
//import { GateDevices } from "./pages/gateDevices";
import GateDevices from "./pages/gateDevices";



import { GateDeviceConfigs } from "./pages/gateDeviceConfigs";
import { GateTokens } from "./pages/gateTokens";
import { GateEntryCreate } from "./pages/gateEntries/create";
import { WeighmentTickets } from "./pages/weighmentTickets";
import { GateMovements } from "./pages/gateMovements";
import GateTokenDetail from "./pages/gateTokens/detail";
import { MandiAssociations } from "./pages/mandiAssociations";
import { PermissionsManager } from "./pages/permissionsManager";
import { AuctionSessions } from "./pages/auctionSessions";
import { AuctionLots } from "./pages/auctionLots";
import { AuctionResults } from "./pages/auctionResults";
import { Lots } from "./pages/lots";
import { LotsCreate } from "./pages/lots/create";
import { TransportIntents } from "./pages/transportIntents";
import { PreMarketListings } from "./pages/preMarketListings";
import { PreMarketListingCreate } from "./pages/preMarketListings/create";
import { PreMarketListingDetail } from "./pages/preMarketListings/detail";
import { MandiPricePolicies } from "./pages/mandiPricePolicies";
import { MandiPricePolicyCreate } from "./pages/mandiPricePolicies/create";
import { MandiSettings } from "./pages/mandiSettings";
import { StallFees } from "./pages/stallFees";
import { StallFeeCollect } from "./pages/stallFees/collect";
import { StallFeeReport } from "./pages/stallFees/report";
import { MarketPrices } from "./pages/marketPrices";
import PublicNewsPage from "./pages/publicNews";
import { PaymentsLanding } from "./pages/paymentsLanding";
import { PaymentModels } from "./pages/paymentModels";
import { OrgPaymentSettings } from "./pages/orgPaymentSettings";
import { OrgSettings } from "./pages/orgSettings";
import { MandiPaymentSettings } from "./pages/mandiPaymentSettings";
import { CommodityFees } from "./pages/commodityFees";
import { PaymentModes } from "./pages/paymentModes";
import { PaymentPayoutSettingsPage } from "./pages/paymentPayoutSettings";
import PlatformModulePaymentGatewaySettingsPage from "./pages/platform-module-payment-gateways";
import PlatformModuleSettlementChargesPage from "./pages/platform-module-settlement-charges";
import { SettlementChargeSettingsPage } from "./pages/settlementChargeSettings";
import { PaymentGatewayConfigsPage } from "./pages/payment-gateway-configs";
import { PaymentTransactionsPage } from "./pages/paymentTransactions";
import PaymentVendorAccountsPage from "./pages/paymentVendorAccounts";
import { CustomFees } from "./pages/customFees";
import { RoleCustomFees } from "./pages/roleCustomFees";
import { SubscriptionsPage } from "./pages/subscriptions";
import { SubscriptionInvoices } from "./pages/subscriptionInvoices";
import { SettlementsPage } from "./pages/settlements/index";
import { PaymentsLog } from "./pages/paymentsLog";
import ResourceRegistryPage from "./pages/resourceRegistry";
import ResourceHealthPage from "./pages/resourceHealth";
import { WorkflowPolicies } from "./pages/workflowPolicies";
import MobileDashboardAdminPage from "./pages/mobileDashboard";
import PlatformControlCenterPage from "./pages/platformControlCenter";
import NotificationTemplates from "./pages/notificationTemplates";
import DirectTradeApprovalsPage from "./pages/directTradeApprovals";
import DirectTradeOrdersPage from "./pages/directTradeOrders";
import BulkTradePage from "./pages/bulkTrade";

import { Layout } from "./components/layout";
import { CmAdminShell } from "./components/layout/CmAdminShell";

import { getUserRoleFromStorage } from "./utils/roles";
import { AdminUiConfigProvider } from "./contexts/admin-ui-config";
import { PermissionsDebugPanel } from "./components/PermissionsDebugPanel";
import { StepUpProvider } from "./security/stepup/StepUpContext";
import { StepUpRouteEnforcer } from "./components/StepUpRouteEnforcer";
import { GlobalErrorBoundary } from "./components/layout/GlobalErrorBoundary";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { TOKEN_KEY } from "./authProvider";
import "./services/apiClient";
import { ApiLoadingProvider } from "./context/ApiLoadingContext";
import { GlobalApiProgressBar } from "./components/GlobalApiProgressBar";
import { CmAntDesignProvider } from "./design-system/CmAntDesignProvider";

function SessionExpiryHandler() {
  const { enqueueSnackbar } = useSnackbar();
  useEffect(() => {
    const handler = () => {
      try {
        localStorage.removeItem(TOKEN_KEY);
      } catch (_) {}
      enqueueSnackbar("Your session has expired. Please sign in again.", { variant: "error" });
      window.location.assign("/admin/login");
    };
    window.addEventListener("cd:session-expired", handler as EventListener);
    return () => window.removeEventListener("cd:session-expired", handler as EventListener);
  }, [enqueueSnackbar]);
  return null;
}

const AdminRoleGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { mutate: logout } = useLogout();

  useEffect(() => {
    const storedUser = localStorage.getItem("cd_user");
    if (!storedUser) {
      logout();
      return;
    }

    const role = getUserRoleFromStorage("AppGuard");
    if (!role) {
      console.warn("[AppGuard] no role resolved for stored user; skipping alert.");
    }
  }, [logout]);

  return <>{children}</>;
};




function App() {
  return (
    <GlobalErrorBoundary>
      <ApiLoadingProvider>
      <GlobalApiProgressBar />
      <BrowserRouter basename="/admin">
      <RefineKbarProvider>
        <ColorModeContextProvider>
          <CmAntDesignProvider>
          <CssBaseline />
          <GlobalStyles
            styles={{
              html: { WebkitFontSmoothing: "auto", height: "100%" },
              body: { margin: 0, padding: 0, height: "100%" },
              "#root": { height: "100%" },
            }}
          />
          <SnackbarProvider anchorOrigin={{ vertical: "top", horizontal: "center" }}>
            <SessionExpiryHandler />
            <RefineSnackbarProvider>
              <Refine
              dataProvider={dataProvider("https://api.fake-rest.refine.dev")}
              notificationProvider={useNotificationProvider}
              routerProvider={routerProvider}
              authProvider={authProvider}
              options={{
                syncWithLocation: true,
                warnWhenUnsavedChanges: true,
                projectId: "CD-ADMIN-PANEL",
              }}
            >
              <Routes>
                <Route
                  element={
                    <Authenticated key="protected-routes" fallback={<Navigate to="/login" replace />}>
                      <AdminRoleGuard>
                        <AdminUiConfigProvider>
                          <StepUpProvider>
                            <PermissionsDebugPanel />
                            <CmAdminShell>
                              <StepUpRouteEnforcer>
                                <Outlet />
                              </StepUpRouteEnforcer>
                            </CmAdminShell>
                          </StepUpProvider>
                        </AdminUiConfigProvider>
                      </AdminRoleGuard>
                    </Authenticated>
                  }
                >
                  <Route index element={<Navigate to="/dashboard" replace />} />
                  <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/operations" element={<MandiManagerOperations />} />
                  <Route path="/approvals" element={<MandiManagerApprovals />} />
                  <Route path="/staff" element={<MandiManagerStaff />} />
                  <Route path="/manager-reports" element={<MandiManagerReports />} />
                  <Route path="/mandi-management" element={<MandiManagerManagement />} />
                  <Route path="/direct-trade-approvals" element={<DirectTradeApprovalsPage />} />
                  <Route path="/platform-operations" element={<Navigate to="/dashboard" replace />} />
                  <Route path="/direct-trade/approvals" element={<DirectTradeApprovalsPage />} />
                  <Route path="/direct-trade/orders" element={<DirectTradeOrdersPage />} />
                  <Route path="/bulk-trade" element={<BulkTradePage />} />
                  <Route path="/system/platform-users" element={<Navigate to="/admin-users" replace />} />
                  <Route path="/platform-users" element={<Navigate to="/admin-users" replace />} />
                  <Route path="/orgs" element={<Orgs />} />
                  <Route path="/mandis" element={<Mandis />} />
                  <Route path="/admin-users" element={<AdminUsers />} />
                  <Route path="/trader-approvals" element={<TraderApprovals />} />
                  <Route path="/farmer-approvals" element={<FarmerApprovals />} />
                  <Route path="/traders" element={<Traders />} />
                  <Route path="/farmers" element={<Farmers />} />
                  <Route path="/mandi-coverage" element={<MandiCoverage />} />
                  <Route path="/mandi-prices" element={<MandiPrices />} />
                  <Route path="/payments-settlements" element={<PaymentsLanding />} />
                  <Route path="/payment-models" element={<PaymentModels />} />
                  <Route path="/org-payment-settings" element={<OrgPaymentSettings />} />
                  <Route path="/org-settings" element={<OrgSettings />} />
                  <Route path="/mandi-payment-settings" element={<MandiPaymentSettings />} />
                  <Route path="/commodity-fees" element={<CommodityFees />} />
                  <Route path="/payment-modes" element={<PaymentModes />} />
                  <Route path="/payment-payout-settings" element={<PaymentPayoutSettingsPage />} />
                  <Route
                    path="/settlement-charge-settings"
                    element={
                      <ProtectedRoute resourceKey="settlement_charge_settings.view">
                        <SettlementChargeSettingsPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/payment-gateway-configs" element={<PaymentGatewayConfigsPage />} />
                  <Route
                    path="/platform-module-payment-gateways"
                    element={
                      <ProtectedRoute resourceKey="platform_module_payment_gateway_configs.list">
                        <PlatformModulePaymentGatewaySettingsPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/platform-module-settlement-charges"
                    element={
                      <ProtectedRoute resourceKey="platform_module_settlement_charges.list">
                        <PlatformModuleSettlementChargesPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/finance/payment-vendor-accounts"
                    element={
                      <ProtectedRoute resourceKey="payment_vendor_accounts.view">
                        <PaymentVendorAccountsPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/payment-vendor-accounts"
                    element={
                      <ProtectedRoute resourceKey="payment_vendor_accounts.view">
                        <PaymentVendorAccountsPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/payment-transactions" element={<PaymentTransactionsPage />} />
                  <Route path="/custom-fees" element={<CustomFees />} />
                  <Route path="/role-custom-fees" element={<RoleCustomFees />} />
                  <Route path="/subscriptions" element={<SubscriptionsPage />} />
                  <Route path="/subscription-invoices" element={<SubscriptionInvoices />} />
                  <Route path="/settlements" element={<SettlementsPage />} />
                  <Route path="/payments-log" element={<PaymentsLog />} />
                  <Route path="/org-mandi-mapping" element={<Navigate to="/mandis" replace />} />
                    <Route path="/org-mandi" element={<Navigate to="/mandis" replace />} />
                    <Route path="/mobile-dashboard" element={<MobileDashboardAdminPage />} />
                    <Route path="/system/mobile-dashboard" element={<MobileDashboardAdminPage />} />
                    <Route path="/system/security" element={<SystemSecurityPage />} />
                    <Route path="/system/security/2fa" element={<TwoFactorSettings />} />
                  <Route path="/masters/commodities" element={<Commodities />} />
                  <Route path="/masters/commodity-products" element={<CommodityProducts />} />
                  <Route path="/masters/mandi-products" element={<MandiCommodityProductsMasters />} />
                  <Route path="/commodities" element={<Navigate to="/masters/commodities" replace />} />
                  <Route path="/commodity-products" element={<Navigate to="/masters/commodity-products" replace />} />
                  <Route path="/mandi-facilities" element={<MandiFacilities />} />
                  <Route path="/mandi-gates" element={<MandiGates />} />
                  <Route path="/mandi-hours-templates" element={<MandiHoursTemplates />} />
                  <Route path="/gate-entry-reasons" element={<GateEntryReasons />} />
                  <Route path="/gate-vehicle-types" element={<GateVehicleTypes />} />
                  <Route path="/auction-methods" element={<AuctionMethods />} />
                  <Route path="/auction-rounds" element={<AuctionRounds />} />
                  <Route path="/auction-policies" element={<AuctionPolicies />} />
                  <Route path="/auction-policy-settings" element={<AuctionPolicySettingsPage />} />
                  <Route path="/auction-settings" element={<AuctionSettings />} />
                  <Route path="/gate-devices" element={<GateDevices />} />
                  <Route path="/gate-device-configs" element={<GateDeviceConfigs />} />
                  <Route path="/gate-tokens" element={<GateTokens />} />
                  <Route path="/gate-entries" element={<GateTokens />} />
                  <Route path="/gate-entries/create" element={<GateEntryCreate />} />
                  <Route path="/gate-tokens/:tokenCode" element={<GateTokenDetail />} />
                  <Route path="/weighment-tickets" element={<WeighmentTickets />} />
                  <Route path="/gate-movements" element={<GateMovements />} />
                  <Route path="/mandi-associations" element={<MandiAssociations />} />
                  <Route path="/admin/mandi-associations" element={<MandiAssociations />} />
                  <Route path="/system/roles-permissions" element={<Navigate to="/system/role-policy-manager" replace />} />
                  <Route path="/system/role-policy-manager" element={<PermissionsManager />} />
                  <Route path="/system/permissions-manager" element={<Navigate to="/system/role-policy-manager" replace />} />
                  <Route path="/system/resource-registry" element={<ResourceRegistryPage />} />
                  <Route path="/system/resource-health" element={<ResourceHealthPage />} />
                  <Route path="/system/platform-control-center" element={<PlatformControlCenterPage />} />
                  <Route path="/system/notifications/templates" element={<NotificationTemplates />} />
                  <Route path="/system/user-role-manager" element={<Navigate to="/admin-users" replace />} />
                  <Route path="/system/security/stepup-policies" element={<StepUpPoliciesPage />} />
                  <Route path="/system/security/switches" element={<SecuritySwitchesPage />} />
                  <Route path="/system/capacity-control" element={<SystemCapacityControlPage />} />
                  <Route path="/system/workflow-policies" element={<WorkflowPolicies />} />
                  <Route path="/auction-sessions" element={<AuctionSessions />} />
                  <Route path="/auction-lots" element={<AuctionLots />} />
                  <Route path="/lots" element={<Lots />} />
                  <Route path="/lots/create" element={<LotsCreate />} />
                  <Route path="/transport-intents" element={<TransportIntents />} />
                  <Route path="/pre-market-listings" element={<PreMarketListings />} />
                  <Route path="/pre-market-listings/create" element={<PreMarketListingCreate />} />
                  <Route path="/pre-market-listings/:id" element={<PreMarketListingDetail />} />
                  <Route path="/mandi-price-policies" element={<MandiPricePolicies />} />
                  <Route path="/mandi-price-policies/create" element={<MandiPricePolicyCreate />} />
                  <Route path="/mandi-settings" element={<MandiSettings />} />
                  <Route path="/stall-fees" element={<StallFees />} />
                  <Route path="/stall-fees/collect" element={<StallFeeCollect />} />
                  <Route path="/stall-fees/report" element={<StallFeeReport />} />
                  <Route path="/market-prices" element={<MarketPrices />} />
                  <Route path="/public-news" element={<PublicNewsPage />} />
                  <Route path="/auction-results" element={<AuctionResults />} />
                  <Route path="/reports" element={<Reports />} />
                  <Route path="/reports" element={<Reports />} />
                  <Route path="*" element={<ErrorComponent />} />
                </Route>

                {/* CM_FORGOT_PASSWORD_FLOW_20251227 */}
                <Route path="/reset-password" element={<ResetPasswordPage />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="*" element={<Navigate to="/login" replace />} />
              </Routes>
                <RefineKbar />
                <UnsavedChangesNotifier />
                {/* <DocumentTitleHandler /> */}
                <DocumentTitleHandler handler={() => "CiberMandi – Admin"} />

              </Refine>
            </RefineSnackbarProvider>
          </SnackbarProvider>
          </CmAntDesignProvider>
        </ColorModeContextProvider>
      </RefineKbarProvider>
      </BrowserRouter>
      </ApiLoadingProvider>
    </GlobalErrorBoundary>
  );
}

export default App;
