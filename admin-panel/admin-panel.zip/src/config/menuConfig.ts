import * as React from "react";
import {
  AppstoreOutlined as DashboardOutlinedIcon,
  ApartmentOutlined as ApartmentOutlinedIcon,
  ShopOutlined as StoreMallDirectoryOutlinedIcon,
  TeamOutlined as GroupsOutlinedIcon,
  CheckCircleOutlined as TaskAltOutlinedIcon,
  EnvironmentOutlined as MapOutlinedIcon,
  DollarOutlined as PriceChangeOutlinedIcon,
  BarChartOutlined as AssessmentOutlinedIcon,
  DeploymentUnitOutlined as HubOutlinedIcon,
  QrcodeOutlined as QrCodeScannerOutlinedIcon,
  ColumnHeightOutlined as ScaleOutlinedIcon,
  LineChartOutlined as TimelineOutlinedIcon,
  IdcardOutlined as BadgeOutlinedIcon,
  AuditOutlined as GavelOutlinedIcon,
  WalletOutlined as AccountBalanceWalletOutlinedIcon,
  BankOutlined as AccountBalanceOutlinedIcon,
  SettingOutlined as SettingsOutlinedIcon,
  FileTextOutlined as ReceiptLongOutlinedIcon,
  InboxOutlined as Inventory2OutlinedIcon,
  SafetyCertificateOutlined as SecurityOutlinedIcon,
  UsergroupAddOutlined as PeopleAltOutlinedIcon,
  NotificationOutlined as CampaignOutlinedIcon,
} from "@ant-design/icons";
import { canonicalizeResourceKey, isDbActive, normalizeRoute, type UiResource } from "../utils/adminUiConfig";
import { computeAllowedSidebar } from "../utils/rbacHelper";
import { MENU_FREEZE } from "./menuFreeze";
import { resolveMenuLabel } from "../utils/uiLabel";
import { resolveMenuIcon } from "./iconRegistry";

export type RoleSlug =
  | "SUPER_ADMIN"
  | "ORG_ADMIN"
  | "ORG_VIEWER"
  | "MANDI_ADMIN"
  | "MANDI_MANAGER"
  | "AUCTIONEER"
  | "GATE_OPERATOR"
  | "YARD_SUPERVISOR"
  | "LOADING_SUPERVISOR"
  | "WEIGHBRIDGE_OPERATOR"
  | "AUDITOR"
  | "VIEWER"
  | "PLATFORM_REVIEWER"
  | "PLATFORM_APPROVER"
  | "PLATFORM_SUPERVISOR"
  | "PLATFORM_OPERATIONS_MANAGER";

export type AppMenuItem = {
  key?: string;
  labelKey: string;
  labelOverride?: string;
  path?: string;
  icon?: React.ReactNode;
  resourceKey?: string;
  requiredAction?: string;
  roles?: RoleSlug[];
  children?: AppMenuItem[];
  order?: number;
  disabled?: boolean;
};

const ALL_ROLES: RoleSlug[] = [
  "SUPER_ADMIN",
  "ORG_ADMIN",
  "ORG_VIEWER",
  "MANDI_ADMIN",
  "MANDI_MANAGER",
  "AUCTIONEER",
  "GATE_OPERATOR",
  "YARD_SUPERVISOR",
  "LOADING_SUPERVISOR",
  "WEIGHBRIDGE_OPERATOR",
  "AUDITOR",
  "VIEWER",
  "PLATFORM_REVIEWER",
  "PLATFORM_APPROVER",
  "PLATFORM_SUPERVISOR",
  "PLATFORM_OPERATIONS_MANAGER",
];

export const APP_MENU: AppMenuItem[] = [
  {
    key: "dashboard",
    labelKey: "menu.dashboard",
    path: "/dashboard",
    icon: React.createElement(DashboardOutlinedIcon),
    resourceKey: "dashboard.menu",
    requiredAction: "VIEW",
    roles: ALL_ROLES,
  },

  {
    key: "mandiOperations",
    labelKey: "menu.mandiOperations",
    labelOverride: "Operations",
    path: "/operations",
    icon: React.createElement(HubOutlinedIcon),
    resourceKey: "mandi_operations.menu",
    requiredAction: "VIEW",
    roles: ["MANDI_MANAGER"],
    order: 11,
  },

  {
    key: "mandiApprovals",
    labelKey: "menu.mandiApprovals",
    labelOverride: "Approvals",
    path: "/approvals",
    icon: React.createElement(TaskAltOutlinedIcon),
    resourceKey: "mandi_approvals.menu",
    requiredAction: "VIEW",
    roles: ["MANDI_MANAGER"],
    order: 12,
  },

  {
    key: "mandiStaff",
    labelKey: "menu.mandiStaff",
    labelOverride: "Staff & Team",
    path: "/staff",
    icon: React.createElement(PeopleAltOutlinedIcon),
    resourceKey: "mandi_staff.menu",
    requiredAction: "VIEW",
    roles: ["MANDI_MANAGER"],
    order: 13,
  },

  {
    key: "mandiReports",
    labelKey: "menu.mandiReports",
    labelOverride: "Reports & MIS",
    path: "/manager-reports",
    icon: React.createElement(AssessmentOutlinedIcon),
    resourceKey: "mandi_reports.menu",
    requiredAction: "VIEW",
    roles: ["MANDI_MANAGER"],
    order: 14,
  },

  {
    key: "mandiManagement",
    labelKey: "menu.mandiManagement",
    labelOverride: "Mandi Management",
    path: "/mandi-management",
    icon: React.createElement(SettingsOutlinedIcon),
    resourceKey: "mandi_management.menu",
    requiredAction: "VIEW",
    roles: ["MANDI_MANAGER"],
    order: 15,
  },

  {
    key: "publicNews",
    labelKey: "menu.publicNews",
    labelOverride: "News & Updates",
    path: "/public-news",
    icon: React.createElement(CampaignOutlinedIcon),
    resourceKey: "public_news.menu",
    requiredAction: "VIEW",
    roles: ["SUPER_ADMIN"],
    order: 295,
  },
  
  // {
  //   key: "organisationsAccess",
  //   labelKey: "menu.organisations",
  //   icon: React.createElement(ApartmentOutlinedIcon),
  //   roles: ALL_ROLES,
  //   children: [
  //     {
  //       key: "organisations",
  //       labelKey: "menu.organisations",
  //       path: "/orgs",
  //       icon: React.createElement(ApartmentOutlinedIcon),
  //       resourceKey: "organisations.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
  //     },
  //     {
  //       key: "orgMandiMapping",
  //       labelKey: "menu.orgMandi",
  //       path: "/org-mandi-mapping",
  //       icon: React.createElement(HubOutlinedIcon),
  //       resourceKey: "org_mandi_mapping.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
  //     },
  //     {
  //       key: "adminUsers",
  //       labelKey: "menu.adminUsers",
  //       path: "/admin-users",
  //       icon: React.createElement(GroupsOutlinedIcon),
  //       resourceKey: "admin_users.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
  //     },
  //   ],
  // },

  {
  key: "organisationsAccess",
  labelKey: "menu.organisations",
  icon: React.createElement(ApartmentOutlinedIcon),
  roles: ALL_ROLES,
  children: [
    {
      key: "organisations",
      labelKey: "menu.organisationsList",   // 👈 changed
      path: "/orgs",
      icon: React.createElement(ApartmentOutlinedIcon),
      resourceKey: "organisations.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
    },
    {
      key: "adminUsers",
      labelKey: "menu.adminUsers",
      path: "/admin-users",
      icon: React.createElement(GroupsOutlinedIcon),
      resourceKey: "admin_users.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN"],
    },
  ],
},


  {
    key: "platformOperations",
    labelKey: "menu.platformOperations",
    labelOverride: "Platform Operations",
    icon: React.createElement(TaskAltOutlinedIcon),
    roles: ["PLATFORM_REVIEWER", "PLATFORM_APPROVER", "PLATFORM_SUPERVISOR", "PLATFORM_OPERATIONS_MANAGER", "SUPER_ADMIN"],
    children: [
      {
        key: "directTradeApprovals",
        labelKey: "menu.directTradeApprovals",
        labelOverride: "Direct Trade Approvals",
        path: "/direct-trade/approvals",
        icon: React.createElement(TaskAltOutlinedIcon),
        resourceKey: "direct_trade_approvals.menu",
        requiredAction: "VIEW",
        roles: ["PLATFORM_REVIEWER", "PLATFORM_APPROVER", "PLATFORM_SUPERVISOR", "PLATFORM_OPERATIONS_MANAGER", "SUPER_ADMIN"],
      },
      {
        key: "directTradeOrders",
        labelKey: "menu.directTradeOrders",
        labelOverride: "Direct Trade Orders",
        path: "/direct-trade/orders",
        icon: React.createElement(TaskAltOutlinedIcon),
        resourceKey: "direct_trade_orders.menu",
        requiredAction: "VIEW",
        roles: ["PLATFORM_REVIEWER", "PLATFORM_APPROVER", "PLATFORM_SUPERVISOR", "PLATFORM_OPERATIONS_MANAGER", "SUPER_ADMIN"],
      },
    ],
  },

      {
        key: "system",
        labelKey: "menu.system",
        icon: React.createElement(SettingsOutlinedIcon),
        roles: ["SUPER_ADMIN"],
        children: [
      {
        key: "systemSecurity",
        labelKey: "menu.systemSecurity",
        path: "/system/security",
        icon: React.createElement(SecurityOutlinedIcon),
        resourceKey: "system_security.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "platformControlCenter",
        labelKey: "menu.platformControlCenter",
        labelOverride: "Platform Controls",
        path: "/system/platform-control-center",
        icon: resolveMenuIcon("security", "platform_control_center.menu"),
        resourceKey: "platform_control_center.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "notifications",
        labelKey: "menu.notifications",
        labelOverride: "Notifications",
        path: "/system/notifications/templates",
        icon: React.createElement(SecurityOutlinedIcon),
        resourceKey: "notification_templates.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "rolesPermissions",
        labelKey: "menu.rolePermissions",
        path: "/system/role-policy-manager",
        icon: React.createElement(SecurityOutlinedIcon),
        resourceKey: "role_policies.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "resourceRegistry",
        labelKey: "menu.resourceRegistry",
        path: "/system/resource-registry",
        icon: React.createElement(SecurityOutlinedIcon),
        resourceKey: "resource_registry.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "resourceHealth",
        labelKey: "menu.resourceHealth",
        path: "/system/resource-health",
        icon: React.createElement(SecurityOutlinedIcon),
        resourceKey: "resource_health.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "workflowPolicies",
        labelKey: "menu.workflowPolicies",
        path: "/system/workflow-policies",
        icon: React.createElement(SecurityOutlinedIcon),
        resourceKey: "workflow_policies.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "mobileDashboard",
        labelKey: "menu.mobileDashboard",
        path: "/system/mobile-dashboard",
        icon: React.createElement(DashboardOutlinedIcon),
        resourceKey: "mobile_dashboard.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "systemCapacityControl",
        labelKey: "menu.systemCapacityControl",
        path: "/system/capacity-control",
        icon: React.createElement(SettingsOutlinedIcon),
        resourceKey: "capacity_control.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
    ],
  },



  // {
  //   key: "mandisGroup",
  //   labelKey: "menu.mandis",
  //   icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  //   roles: ALL_ROLES,
  //   children: [
  //     {
  //       key: "mandis",
  //       labelKey: "menu.mandis",
  //       path: "/mandis",
  //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  //       resourceKey: "mandis.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
  //     },
  //     {
  //       key: "commodities",
  //       labelKey: "menu.commodities",
  //       path: "/commodities",
  //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  //       resourceKey: "commodities_masters.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
  //     },
  //     {
  //       key: "commodityProducts",
  //       labelKey: "menu.commodityProducts",
  //       path: "/commodity-products",
  //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  //       resourceKey: "commodity_products_masters.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
  //     },
  //     {
  //       key: "mandiFacilities",
  //       labelKey: "menu.mandiFacilities",
  //       path: "/mandi-facilities",
  //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  //       resourceKey: "mandi_facilities.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
  //     },
  //     {
  //       key: "mandiGates",
  //       labelKey: "menu.mandiGates",
  //       path: "/mandi-gates",
  //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  //       resourceKey: "mandi_gates.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
  //     },
  //     {
  //       key: "mandiHours",
  //       labelKey: "menu.mandiHoursTemplates",
  //       path: "/mandi-hours-templates",
  //       icon: React.createElement(Inventory2OutlinedIcon),
  //       resourceKey: "mandi_hours.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
  //     },
  //   ],
  // },
  {
  key: "mandisGroup",
  labelKey: "menu.mandis",
  icon: React.createElement(StoreMallDirectoryOutlinedIcon),
  roles: ALL_ROLES,
  children: [
    {
      key: "mandis",
      labelKey: "menu.mandisList",  // 👈 changed
      path: "/mandis",
      icon: React.createElement(StoreMallDirectoryOutlinedIcon),
      resourceKey: "mandis.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
    },
    {
      key: "commodities",
      labelKey: "menu.commodities",
      path: "/masters/commodities",
      icon: React.createElement(StoreMallDirectoryOutlinedIcon),
      resourceKey: "commodities_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
    },
    {
      key: "commodityProducts",
      labelKey: "menu.commodityProducts",
      path: "/masters/commodity-products",
      icon: React.createElement(StoreMallDirectoryOutlinedIcon),
      resourceKey: "commodity_products_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
    },
    {
      key: "mandiCommodityProducts",
      labelKey: "menu.mandiCommodityProducts",
      path: "/masters/mandi-products",
      icon: React.createElement(StoreMallDirectoryOutlinedIcon),
      resourceKey: "mandi_commodity_products_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
    },
    {
      key: "mandiFacilities",
      labelKey: "menu.mandiFacilities",
      path: "/mandi-facilities",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "mandi_facilities.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
    },
    {
      key: "mandiHours",
      labelKey: "menu.mandiHoursTemplates",
      path: "/mandi-hours-templates",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "mandi_hours.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
    },
  ],
},

  // {
  //   key: "gateYard",
  //   labelKey: "menu.gateEntryReasons",
  //   icon: React.createElement(QrCodeScannerOutlinedIcon),
  //   roles: ALL_ROLES,
  //   children: [
  //     {
  //       key: "gateEntryReasons",
  //       labelKey: "menu.gateEntryReasons",
  //       path: "/gate-entry-reasons",
  //       icon: React.createElement(QrCodeScannerOutlinedIcon),
  //       resourceKey: "gate_entry_reasons_masters.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //     {
  //       key: "gateVehicleTypes",
  //       labelKey: "menu.gateVehicleTypes",
  //       path: "/gate-vehicle-types",
  //       icon: React.createElement(QrCodeScannerOutlinedIcon),
  //       resourceKey: "gate_vehicle_types_masters.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //     {
  //       key: "gateDevices",
  //       labelKey: "menu.gateDevices",
  //       path: "/gate-devices",
  //       icon: React.createElement(QrCodeScannerOutlinedIcon),
  //       resourceKey: "cm_gate_devices.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //     {
  //       key: "gateDeviceConfigs",
  //       labelKey: "menu.gateDeviceConfigs",
  //       path: "/gate-device-configs",
  //       icon: React.createElement(QrCodeScannerOutlinedIcon),
  //       resourceKey: "gate_device_configs.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //     {
  //       key: "gateTokens",
  //       labelKey: "menu.gateTokens",
  //       path: "/gate-tokens",
  //       icon: React.createElement(QrCodeScannerOutlinedIcon),
  //       resourceKey: "gate_pass_tokens.view",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //     {
  //       key: "gateMovements",
  //       labelKey: "menu.gateMovements",
  //       path: "/gate-movements",
  //       icon: React.createElement(TimelineOutlinedIcon),
  //       resourceKey: "gate_movements_log.view",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //     {
  //       key: "weighmentTickets",
  //       labelKey: "menu.weighmentTickets",
  //       path: "/weighment-tickets",
  //       icon: React.createElement(ScaleOutlinedIcon),
  //       resourceKey: "weighment_tickets.view",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
  //     },
  //   ],
  // },

{
  key: "gateYard",
  labelKey: "menu.gateYard",
  icon: React.createElement(QrCodeScannerOutlinedIcon),
  roles: ALL_ROLES,
  children: [
    {
      key: "gateEntryReasons",
      labelKey: "menu.gateEntryReasonsMaster",  // 👈 changed
      path: "/gate-entry-reasons",
      icon: React.createElement(QrCodeScannerOutlinedIcon),
      resourceKey: "gate_entry_reasons_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "gateVehicleTypes",
      labelKey: "menu.gateVehicleTypes",
      path: "/gate-vehicle-types",
      icon: React.createElement(QrCodeScannerOutlinedIcon),
      resourceKey: "gate_vehicle_types_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "mandiGates",
      labelKey: "menu.mandiGates",
      path: "/mandi-gates",
      icon: React.createElement(QrCodeScannerOutlinedIcon),
      resourceKey: "mandi_gates.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "gateDevices",
      labelKey: "menu.gateDevices",
      path: "/gate-devices",
      icon: React.createElement(QrCodeScannerOutlinedIcon),
      // Use legacy key to match current policy assignments (canonical: gate_devices.menu)
      resourceKey: "gate_devices.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "gateDeviceConfigs",
      labelKey: "menu.gateDeviceConfigs",
      path: "/gate-device-configs",
      icon: React.createElement(QrCodeScannerOutlinedIcon),
      resourceKey: "gate_device_configs.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "gateEntries",
      labelKey: "menu.gateEntries",
      path: "/gate-tokens",
      icon: React.createElement(TimelineOutlinedIcon),
      resourceKey: "gate_entry_tokens.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "GATE_OPERATOR", "WEIGHBRIDGE_OPERATOR"],
    },
    {
      key: "preMarketListings",
      labelKey: "menu.preMarketListings",
      path: "/pre-market-listings",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "pre_market_listings.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "GATE_OPERATOR", "WEIGHBRIDGE_OPERATOR"],
    },
    {
      key: "stallFees",
      labelKey: "menu.stallFees",
      path: "/stall-fees",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "stall_fees.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "GATE_OPERATOR", "WEIGHBRIDGE_OPERATOR"],
    },
    {
      key: "marketPrices",
      labelKey: "menu.marketPrices",
      path: "/market-prices",
      icon: React.createElement(PriceChangeOutlinedIcon),
      resourceKey: "market_prices.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "GATE_OPERATOR", "WEIGHBRIDGE_OPERATOR"],
    },
    {
      key: "mandiPricePolicies",
      labelKey: "menu.mandiPricePolicies",
      path: "/mandi-price-policies",
      icon: React.createElement(PriceChangeOutlinedIcon),
      resourceKey: "mandi_price_policies.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
    },
    {
      key: "mandiSettings",
      labelKey: "menu.mandiSettings",
      path: "/mandi-settings",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "mandi_settings.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
    },
    {
      key: "transportIntents",
      labelKey: "menu.transportIntents",
      path: "/transport-intents",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "transport_intents.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "GATE_OPERATOR", "WEIGHBRIDGE_OPERATOR"],
    },
    {
      key: "mandiAssociations",
      labelKey: "menu.mandiAssociations",
      path: "/admin/mandi-associations",
      icon: React.createElement(TimelineOutlinedIcon),
      resourceKey: "mandi_associations.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
    },
    {
      key: "gateMovements",
      labelKey: "menu.gateMovements",
      path: "/gate-movements",
      icon: React.createElement(TimelineOutlinedIcon),
      resourceKey: "gate_movements_log.view",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "GATE_OPERATOR", "WEIGHBRIDGE_OPERATOR"],
    },
    {
      key: "weighmentTickets",
      labelKey: "menu.weighmentTickets",
      path: "/weighment-tickets",
      icon: React.createElement(ScaleOutlinedIcon),
      resourceKey: "weighment_tickets.view",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "WEIGHBRIDGE_OPERATOR"],
    },
  ],
},

  // {
  //   key: "auctions",
  //   labelKey: "menu.auctionMethods",
  //   icon: React.createElement(GavelOutlinedIcon),
  //   roles: ALL_ROLES,
  //   children: [
  //     {
  //       key: "auctionMethods",
  //       labelKey: "menu.auctionMethods",
  //       path: "/auction-methods",
  //       icon: React.createElement(GavelOutlinedIcon),
  //       resourceKey: "auction_methods_masters.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
  //     },
  //     {
  //       key: "auctionRounds",
  //       labelKey: "menu.auctionRounds",
  //       path: "/auction-rounds",
  //       icon: React.createElement(GavelOutlinedIcon),
  //       resourceKey: "auction_rounds_masters.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
  //     },
  //     {
  //       key: "auctionPolicies",
  //       labelKey: "menu.auctionPolicies",
  //       path: "/auction-policies",
  //       icon: React.createElement(GavelOutlinedIcon),
  //       resourceKey: "cm_mandi_auction_policies.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
  //     },
  //     {
  //       key: "auctionSessions",
  //       labelKey: "menu.auctionSessions",
  //       path: "/auction-sessions",
  //       icon: React.createElement(GavelOutlinedIcon),
  //       resourceKey: "auction_sessions.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
  //     },
  //     {
  //       key: "auctionLots",
  //       labelKey: "menu.auctionLots",
  //       path: "/auction-lots",
  //       icon: React.createElement(GavelOutlinedIcon),
  //       resourceKey: "auction_lots.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
  //     },
  //     {
  //       key: "auctionResults",
  //       labelKey: "menu.auctionResults",
  //       path: "/auction-results",
  //       icon: React.createElement(GavelOutlinedIcon),
  //       resourceKey: "auction_results.menu",
  //       requiredAction: "VIEW",
  //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
  //     },
  //   ],
  // },

{
  key: "auctions",
  labelKey: "menu.auction",
  labelOverride: "Auction",
  icon: React.createElement(GavelOutlinedIcon),
  roles: ALL_ROLES,
  children: [
    {
      key: "auctionMethods",
      labelKey: "menu.auctionMethodsMaster",  // 👈 changed
      path: "/auction-methods",
      icon: React.createElement(GavelOutlinedIcon),
      resourceKey: "auction_methods_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN"],
    },
    {
      key: "auctionRounds",
      labelKey: "menu.auctionRounds",
      path: "/auction-rounds",
      icon: React.createElement(GavelOutlinedIcon),
      resourceKey: "auction_rounds_masters.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN"],
    },
    {
      key: "auctionPolicies",
      labelKey: "menu.auctionPolicies",
      path: "/auction-policies",
      icon: React.createElement(GavelOutlinedIcon),
      resourceKey: "cm_mandi_auction_policies.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN"],
    },
    {
      key: "auctionPolicySettings",
      labelKey: "menu.auctionPolicySettings",
      labelOverride: "Auction Policy Settings",
      path: "/auction-policy-settings",
      icon: React.createElement(SettingsOutlinedIcon),
      resourceKey: "auction_policy_settings.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN"],
    },
    {
      key: "auctionSettings",
      labelKey: "menu.auctionSettings",
      labelOverride: "Auction Settings",
      path: "/auction-settings",
      icon: React.createElement(SettingsOutlinedIcon),
      resourceKey: "mandi_settings.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "auctionSessions",
      labelKey: "menu.auctionSessions",
      path: "/auction-sessions",
      icon: React.createElement(GavelOutlinedIcon),
      resourceKey: "auction_sessions.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUCTIONEER", "AUDITOR"],
    },
    {
      key: "auctionLots",
      labelKey: "menu.auctionLots",
      path: "/auction-lots",
      icon: React.createElement(GavelOutlinedIcon),
      resourceKey: "auction_lots.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUCTIONEER", "AUDITOR"],
    },
    {
      key: "lots",
      labelKey: "menu.lots",
      path: "/lots",
      icon: React.createElement(Inventory2OutlinedIcon),
      resourceKey: "lots.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUCTIONEER", "AUDITOR"],
    },
    {
      key: "auctionResults",
      labelKey: "menu.auctionResults",
      path: "/auction-results",
      icon: React.createElement(GavelOutlinedIcon),
      resourceKey: "auction_results.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
    },
  ],
},




{
  key: "parties",
  labelKey: "menu.participantManagement",
  icon: React.createElement(TaskAltOutlinedIcon),
  roles: ALL_ROLES,
  children: [
    {
      key: "traderApprovals",
      labelKey: "menu.traderMembershipApprovals",
      path: "/trader-approvals",
      icon: React.createElement(TaskAltOutlinedIcon),
      resourceKey: "trader_approvals.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "farmerApprovals",
      labelKey: "menu.farmerMembershipApprovals",
      path: "/farmer-approvals",
      icon: React.createElement(TaskAltOutlinedIcon),
      resourceKey: "farmer_approvals.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
    },
    {
      key: "traders",
      labelKey: "menu.traders",
      path: "/traders",
      icon: React.createElement(BadgeOutlinedIcon),
      resourceKey: "traders.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "ORG_VIEWER", "AUDITOR"],
    },
    {
      key: "farmersDirectory",
      labelKey: "menu.farmersDirectory",
      path: "/farmers",
      icon: React.createElement(BadgeOutlinedIcon),
      resourceKey: "farmers.menu",
      requiredAction: "VIEW",
      roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "ORG_VIEWER", "AUDITOR"],
    },
  ],
},



  {
    key: "payments",
    labelKey: "menu.paymentsAndSettlements",
    icon: React.createElement(AccountBalanceWalletOutlinedIcon),
    roles: ALL_ROLES,
    children: [
      {
        key: "paymentModels",
        labelKey: "menu.paymentModels",
        path: "/payment-models",
        icon: React.createElement(AccountBalanceWalletOutlinedIcon),
        resourceKey: "payment_models.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "orgPaymentSettings",
        labelKey: "menu.orgPaymentSettings",
        path: "/org-payment-settings",
        icon: React.createElement(AccountBalanceOutlinedIcon),
        resourceKey: "org_payment_settings.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "mandiPaymentSettings",
        labelKey: "menu.mandiPaymentSettings",
        path: "/mandi-payment-settings",
        icon: React.createElement(StoreMallDirectoryOutlinedIcon),
        resourceKey: "mandi_payment_settings.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "commodityFees",
        labelKey: "menu.commodityFeeSettings",
        path: "/commodity-fees",
        icon: React.createElement(Inventory2OutlinedIcon),
        resourceKey: "commodity_fees.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "paymentModes",
        labelKey: "menu.paymentModes",
        path: "/payment-modes",
        icon: React.createElement(SettingsOutlinedIcon),
        resourceKey: "payment_modes.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "paymentPayoutSettings",
        labelKey: "menu.paymentPayoutSettings",
        labelOverride: "Payment & Payout Settings",
        path: "/payment-payout-settings",
        icon: React.createElement(SettingsOutlinedIcon),
        resourceKey: "payment_payout_settings.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "paymentGatewayConfigs",
        labelKey: "menu.paymentGatewaySettings",
        labelOverride: "Payment Gateway Settings",
        path: "/payment-gateway-configs",
        icon: React.createElement(SettingsOutlinedIcon),
        resourceKey: "payment_gateway_configs.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "platformModulePaymentGatewayConfigs",
        labelKey: "menu.platformModulePaymentGatewaySettings",
        labelOverride: "Platform Module Gateway Settings",
        path: "/platform-module-payment-gateways",
        icon: React.createElement(SettingsOutlinedIcon),
        resourceKey: "platform_module_payment_gateway_configs.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "platformModuleSettlementCharges",
        labelKey: "menu.platformModuleSettlementCharges",
        labelOverride: "Platform Module Settlement Charges",
        path: "/platform-module-settlement-charges",
        icon: React.createElement(PriceChangeOutlinedIcon),
        resourceKey: "platform_module_settlement_charges.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN"],
      },
      {
        key: "settlementChargeSettings",
        labelKey: "menu.settlementChargeSettings",
        labelOverride: "Settlement Charge Settings",
        path: "/settlement-charge-settings",
        icon: React.createElement(AccountBalanceWalletOutlinedIcon),
        resourceKey: "settlement_charge_settings.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "paymentVendorAccounts",
        labelKey: "menu.paymentVendorAccounts",
        labelOverride: "Payment Vendor Accounts",
        path: "/payment-vendor-accounts",
        icon: React.createElement(AccountBalanceWalletOutlinedIcon),
        resourceKey: "payment_vendor_accounts.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "ORG_VIEWER"],
      },
      {
        key: "paymentTransactions",
        labelKey: "menu.paymentTransactions",
        path: "/payment-transactions",
        icon: React.createElement(ReceiptLongOutlinedIcon),
        resourceKey: "payment_transactions.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "customFees",
        labelKey: "menu.customFees",
        path: "/custom-fees",
        icon: React.createElement(ReceiptLongOutlinedIcon),
        resourceKey: "custom_fees.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "roleCustomFees",
        labelKey: "menu.roleCustomFees",
        path: "/role-custom-fees",
        icon: React.createElement(GroupsOutlinedIcon),
        resourceKey: "role_custom_fees.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "subscriptions",
        labelKey: "menu.subscriptions",
        path: "/subscriptions",
        icon: React.createElement(AccountBalanceOutlinedIcon),
        resourceKey: "subscriptions.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "subscriptionInvoices",
        labelKey: "menu.subscriptionInvoices",
        path: "/subscription-invoices",
        icon: React.createElement(ReceiptLongOutlinedIcon),
        resourceKey: "subscription_invoices.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "settlements",
        labelKey: "menu.settlements",
        path: "/settlements",
        icon: React.createElement(AssessmentOutlinedIcon),
        resourceKey: "settlements.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
      {
        key: "paymentsLog",
        labelKey: "menu.paymentsLog",
        path: "/payments-log",
        icon: React.createElement(ReceiptLongOutlinedIcon),
        resourceKey: "payments_log.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
      },
    ],
  },




  {
    key: "reports",
    labelKey: "menu.reports",
    icon: React.createElement(MapOutlinedIcon),
    roles: ALL_ROLES,
    children: [
      {
        key: "mandiCoverage",
        labelKey: "menu.mandiCoverage",
        path: "/mandi-coverage",
        icon: React.createElement(MapOutlinedIcon),
        resourceKey: "mandi_coverage.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
      },
      {
        key: "mandiPrices",
        labelKey: "menu.mandiPrices",
        path: "/mandi-prices",
        icon: React.createElement(PriceChangeOutlinedIcon),
        resourceKey: "mandi_prices.menu",
        requiredAction: "VIEW",
        roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "MANDI_ADMIN", "MANDI_MANAGER", "AUCTIONEER", "AUDITOR", "VIEWER"],
      },
    ],
  },
];

function cloneMenuItem(item: AppMenuItem, overrides: Partial<AppMenuItem> = {}): AppMenuItem {
  return {
    ...item,
    ...overrides,
  };
}

function filterHierarchy(
  items: AppMenuItem[],
  predicate: (item: AppMenuItem, hasChildren: boolean) => boolean,
): AppMenuItem[] {
  const results: AppMenuItem[] = [];
  for (const item of items) {
    const filteredChildren = item.children ? filterHierarchy(item.children, predicate) : [];
    const hasChildren = filteredChildren.length > 0;
    const visible = predicate(item, hasChildren) || hasChildren;
    if (visible) {
      const node: AppMenuItem = cloneMenuItem(item, {
        children: filteredChildren.length ? filteredChildren : undefined,
      });
      results.push(node);
    }
  }
  return results;
}

export type MenuItem = AppMenuItem;

const GROUP_LABELS: Record<string, string> = {
  "Dashboard": "Dashboard",
  "Organisation & Access": "Organisations",
  "Organisations": "Organisations",
  "System": "System",
  "Mandi Setup": "Mandis",
  "Masters": "Mandis",
  "Mandis": "Mandis",
  "Gate & Yard": "Gate & Yard",
  "Operations": "Gate & Yard",
  "Auction": "Auction",
  "Registry": "Participant Management",
  "Trader Approvals": "Participant Management",
  "Participant Management": "Participant Management",
  "Finance": "Payments & Settlements",
  "Payments & Settlements": "Payments & Settlements",
  "Reports": "Reports",
};

const GROUP_ORDER: Record<string, number> = {
  "Dashboard": 10,
  "Organisations": 20,
  "System": 30,
  "Mandis": 40,
  "Gate & Yard": 50,
  "Auction": 60,
  "Participant Management": 70,
  "Payments & Settlements": 80,
  "Reports": 90,
};

function normalizeGroupLabel(category?: string | null) {
  const raw = String(category || "").trim();
  return GROUP_LABELS[raw] || raw || "System";
}

export function filterMenuByRole(role: RoleSlug | null) {
  const knownRole = role && ALL_ROLES.includes(role);
  const effectiveRole: RoleSlug = knownRole ? role : "VIEWER";

  if (!knownRole) {
    console.warn(
      "[menuConfig/filterMenuByRole] Unknown or missing role; using VIEWER fallback.",
      { inputRole: role },
    );
  }

  return filterHierarchy(APP_MENU, (item, hasChildren) => {
    // For group containers without their own permission role check, hide if no visible children.
    if (!item.path && !item.resourceKey && !hasChildren) return false;
    if (!item.roles || item.roles.length === 0) return true;
    return item.roles.includes(effectiveRole);
  });
}

function findMenuItemByResourceKey(
  items: AppMenuItem[],
  targetResourceKey: string,
): AppMenuItem | null {
  const target = canonicalizeResourceKey(targetResourceKey);
  for (const item of items) {
    if (canonicalizeResourceKey(item.resourceKey) === target) {
      return item;
    }
    if (item.children?.length) {
      const childMatch = findMenuItemByResourceKey(item.children, targetResourceKey);
      if (childMatch) return childMatch;
    }
  }
  return null;
}

export function filterMenuByResources(
  resources: UiResource[] | undefined,
  fallbackRole: RoleSlug | null,
  permissionsMap?: Record<string, Set<string>>,
) {
  try {
    const normalizedRole = String(fallbackRole || "")
      .trim()
      .toUpperCase()
      .replace(/[\s-]+/g, "_");
    const isSuperAdmin = normalizedRole === "SUPER_ADMIN";
    const hasResources = Array.isArray(resources) && resources.length > 0;
    if (!hasResources) {
      return isSuperAdmin ? filterMenuByRole("SUPER_ADMIN") : [];
    }
    const hasPermissions =
      permissionsMap && Object.keys(permissionsMap).length > 0;
    // If permissions have not been loaded yet, do not render a temporary menu –
    // this avoids the “full menu then collapse” flicker for limited roles.
    if (!hasPermissions && !isSuperAdmin) {
      return [];
    }
    // SUPER_ADMIN visibility fallback: keep menu/resource loading resilient even if
    // policy docs are sparse. This is visibility-only and does not grant write actions.
    const dbMenuRows = resources.filter((res) => String(res?.ui_type || "").trim().toUpperCase() === "MENU");
    const dbMenusByResourceKey = new Map<string, UiResource>();
    const dbMenusByRoute = new Map<string, UiResource>();
    dbMenuRows.forEach((res) => {
      const key = canonicalizeResourceKey(res.resource_key);
      const route = normalizeRoute(res.route);
      if (key) dbMenusByResourceKey.set(key, res);
      if (route && !dbMenusByRoute.has(route)) dbMenusByRoute.set(route, res);
    });

    const allowedMenus = isSuperAdmin
      ? dbMenuRows.filter((res) => isDbActive((res as any)?.is_active))
      : computeAllowedSidebar(resources, permissionsMap!);
    const byKey = new Map<string, UiResource>();
    allowedMenus.forEach((res) => {
      if (res.resource_key) byKey.set(canonicalizeResourceKey(res.resource_key), res);
    });

    const freezeItems = MENU_FREEZE.filter((item) => item && item.resource_key);

    type MenuItemRow = AppMenuItem & { order: number; category: string; resource: UiResource };
    const items: MenuItemRow[] = [];
    freezeItems.forEach((freeze) => {
      const key = canonicalizeResourceKey(freeze.resource_key);
      // Runtime sidebar visibility is permission-driven. `roles` on APP_MENU is
      // legacy presentation metadata only and must never act as a second
      // authorization gate. If RBAC grants VIEW for an active menu resource,
      // the menu is eligible to render regardless of role slug.
      const dbMenu = dbMenusByResourceKey.get(key) || (!key ? dbMenusByRoute.get(normalizeRoute(freeze.route)) : undefined);
      if (dbMenu && !isDbActive((dbMenu as any).is_active)) return;
      if (!dbMenu && !isSuperAdmin) return;
      const effectiveKey = canonicalizeResourceKey(dbMenu?.resource_key || freeze.resource_key);
      const resource = byKey.get(effectiveKey) || byKey.get(key);
      const canViewByPermission = isSuperAdmin || Boolean(permissionsMap?.[effectiveKey]?.has("VIEW")) || Boolean(permissionsMap?.[key]?.has("VIEW"));
      if (!resource && !canViewByPermission) return;
      if (!dbMenu && !isDbActive(freeze.is_active)) return;
      const labelOverride = resolveMenuLabel({
        ...resource,
        resource_key: resource?.resource_key || freeze.resource_key,
        resourceKey: resource?.resource_key || freeze.resource_key,
        label: (resource as any)?.label,
        title: (resource as any)?.title,
        display_name: (resource as any)?.display_name,
        label_i18n: (resource as any)?.label_i18n,
        i18n: (resource as any)?.i18n,
        i18n_label_key: resource?.i18n_label_key || freeze.i18n_key,
      }) || resolveMenuLabel({
        resource_key: freeze.resource_key,
        i18n_label_key: freeze.i18n_key,
        label: freeze.menu_name,
      });
      const labelKey = freeze.i18n_key || resource?.i18n_label_key || resource?.resource_key || freeze.resource_key;
      const path = dbMenu?.route || freeze.route || "";
      const disabled = !path;
      items.push({
        key: String(dbMenu?.resource_key || freeze.resource_key),
        labelKey: String(labelKey),
        labelOverride: String(labelOverride),
        path: disabled ? undefined : String(path),
        icon: resolveMenuIcon(freeze.icon_key || (resource as any).icon_key, freeze.resource_key),
        resourceKey: String(dbMenu?.resource_key || freeze.resource_key),
        requiredAction: "VIEW",
        order: typeof dbMenu?.order === "number" ? dbMenu.order : typeof freeze.order === "number" ? freeze.order : 9999,
        category: normalizeGroupLabel(freeze.category),
        disabled,
        resource:
          resource ||
          {
            resource_key: String(freeze.resource_key),
            ui_type: "MENU",
            allowed_actions: ["VIEW"],
          },
      });
    });

    const systemCapacityControlItem = findMenuItemByResourceKey(APP_MENU, "capacity_control.menu");
    const systemCapacityControlKey = canonicalizeResourceKey("capacity_control.menu");
    const systemCapacityControlPermissionMatch = Boolean(
      permissionsMap?.[systemCapacityControlKey]?.has("VIEW"),
    );
    // Capacity Control follows the same RBAC-only visibility rule. Do not
    // hard-code role slugs here; the role policy is the source of truth.
    const systemCapacityControlResource = byKey.get(systemCapacityControlKey);
    const systemCapacityControlDbMenu =
      dbMenusByResourceKey.get(systemCapacityControlKey);

    if (
      systemCapacityControlItem &&
      (!systemCapacityControlDbMenu || isDbActive((systemCapacityControlDbMenu as any).is_active)) &&
      systemCapacityControlPermissionMatch &&
      !items.some((item) => canonicalizeResourceKey(item.resourceKey) === systemCapacityControlKey)
    ) {
      items.push({
        key: String(systemCapacityControlItem.key || systemCapacityControlKey),
        labelKey: String(systemCapacityControlItem.labelKey),
        labelOverride: systemCapacityControlItem.labelOverride,
        path: systemCapacityControlItem.path,
        icon: systemCapacityControlItem.icon,
        resourceKey: "capacity_control.menu",
        requiredAction: "VIEW",
        order: typeof systemCapacityControlItem.order === "number" ? systemCapacityControlItem.order : 9999,
        category: normalizeGroupLabel("System"),
        disabled: !systemCapacityControlItem.path,
        resource: systemCapacityControlResource || {
          resource_key: "capacity_control.menu",
          ui_type: "MENU",
          allowed_actions: ["VIEW"],
        },
      });
    }

    const categories = new Map<string, { label: string; order: number; items: MenuItemRow[] }>();
    const categoryOrder = new Map<string, number>();
    freezeItems.forEach((f, idx) => {
      const name = normalizeGroupLabel(f.category);
      if (!name) return;
      if (!categoryOrder.has(name)) categoryOrder.set(name, GROUP_ORDER[name] ?? idx);
    });

    items.forEach((item) => {
      const categoryName = normalizeGroupLabel(item.category || "System");
      if (!categories.has(categoryName)) {
        categories.set(categoryName, {
          label: categoryName,
          order: GROUP_ORDER[categoryName] ?? categoryOrder.get(categoryName) ?? 9999,
          items: [],
        });
      }
      categories.get(categoryName)!.items.push(item);
    });

    const grouped = Array.from(categories.entries())
      .map(([key, value]) => {
      const children = value.items
        .sort((a, b) => {
          if ((a as any).order !== (b as any).order) return (a as any).order - (b as any).order;
          return String(a.labelOverride || a.labelKey).localeCompare(String(b.labelOverride || b.labelKey));
        })
        .map((item) => {
          const { order, category, resource, ...rest } = item;
          return rest;
        });
        return {
          key: `category-${key}`,
          labelKey: `menu.category.${key}`,
          labelOverride: value.label,
          children,
          order: value.order,
        };
      })
      .filter((group) => group.children.length > 0)
      .sort((a, b) => a.order - b.order)
      .map(({ order, ...rest }) => rest);

    return grouped as AppMenuItem[];
  } catch (e) {
    console.error("[sidebar] build failed", e, { sample: (resources || []).slice(0, 5) });
    return [];
  }
}


// import * as React from "react";
// import { type UiResource } from "../utils/adminUiConfig";
// 
// export type RoleSlug =
//   | "SUPER_ADMIN"
//   | "ORG_ADMIN"
//   | "ORG_VIEWER"
//   | "MANDI_ADMIN"
//   | "MANDI_MANAGER"
//   | "AUCTIONEER"
//   | "GATE_OPERATOR"
//   | "WEIGHBRIDGE_OPERATOR"
//   | "AUDITOR"
//   | "VIEWER";

// export type AppMenuItem = {
//   key?: string;
//   labelKey: string;
//   path?: string;
//   icon?: React.ReactNode;
//   resourceKey?: string;
//   requiredAction?: string;
//   roles?: RoleSlug[];
//   children?: AppMenuItem[];
// };

// const ALL_ROLES: RoleSlug[] = [
//   "SUPER_ADMIN",
//   "ORG_ADMIN",
//   "ORG_VIEWER",
//   "MANDI_ADMIN",
//   "MANDI_MANAGER",
//   "AUCTIONEER",
//   "GATE_OPERATOR",
//   "WEIGHBRIDGE_OPERATOR",
//   "AUDITOR",
//   "VIEWER",
// ];

// export const APP_MENU: AppMenuItem[] = [
//   {
//     key: "dashboard",
//     labelKey: "menu.dashboard",
//     path: "/dashboard",
//     icon: React.createElement(DashboardOutlinedIcon),
//     resourceKey: "dashboard.menu",
//     requiredAction: "VIEW",
//     roles: ALL_ROLES,
//   },
  
//   // {
//   //   key: "organisationsAccess",
//   //   labelKey: "menu.organisations",
//   //   icon: React.createElement(ApartmentOutlinedIcon),
//   //   roles: ALL_ROLES,
//   //   children: [
//   //     {
//   //       key: "organisations",
//   //       labelKey: "menu.organisations",
//   //       path: "/orgs",
//   //       icon: React.createElement(ApartmentOutlinedIcon),
//   //       resourceKey: "organisations.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "orgMandiMapping",
//   //       labelKey: "menu.orgMandi",
//   //       path: "/org-mandi-mapping",
//   //       icon: React.createElement(HubOutlinedIcon),
//   //       resourceKey: "org_mandi_mapping.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "adminUsers",
//   //       labelKey: "menu.adminUsers",
//   //       path: "/admin-users",
//   //       icon: React.createElement(GroupsOutlinedIcon),
//   //       resourceKey: "admin_users.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//   //     },
//   //   ],
//   // },

//   {
//   key: "organisationsAccess",
//   labelKey: "menu.organisations",
//   icon: React.createElement(ApartmentOutlinedIcon),
//   roles: ALL_ROLES,
//   children: [
//     {
//       key: "organisations",
//       labelKey: "menu.organisationsList",   // 👈 changed
//       path: "/orgs",
//       icon: React.createElement(ApartmentOutlinedIcon),
//       resourceKey: "organisations.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
//     },
//     {
//       key: "orgMandiMapping",
//       labelKey: "menu.orgMandi",
//       path: "/org-mandi-mapping",
//       icon: React.createElement(HubOutlinedIcon),
//       resourceKey: "org_mandi_mapping.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "AUDITOR"],
//     },
//     {
//       key: "adminUsers",
//       labelKey: "menu.adminUsers",
//       path: "/admin-users",
//       icon: React.createElement(GroupsOutlinedIcon),
//       resourceKey: "admin_users.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//     },
//   ],
// },

//   {
//     key: "system",
//     labelKey: "menu.system",
//     icon: React.createElement(SettingsOutlinedIcon),
//     roles: ["SUPER_ADMIN"],
//     children: [
//       {
//         key: "userRoleManager",
//         labelKey: "menu.userRoleManager",
//         path: "/system/user-role-manager",
//         icon: React.createElement(SecurityOutlinedIcon),
//         resourceKey: "user_roles.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN"],
//       },
//       {
//         key: "rolesPermissions",
//         labelKey: "menu.rolePermissions",
//         path: "/system/role-policy-manager",
//         icon: React.createElement(SecurityOutlinedIcon),
//         resourceKey: "menu.role_policies",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN"],
//       },
//       {
//         key: "resourceRegistry",
//         labelKey: "menu.resourceRegistry",
//         path: "/system/resource-registry",
//         icon: React.createElement(SecurityOutlinedIcon),
//         resourceKey: "resource_registry.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN"],
//       },
//     ],
//   },



//   // {
//   //   key: "mandisGroup",
//   //   labelKey: "menu.mandis",
//   //   icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   //   roles: ALL_ROLES,
//   //   children: [
//   //     {
//   //       key: "mandis",
//   //       labelKey: "menu.mandis",
//   //       path: "/mandis",
//   //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   //       resourceKey: "mandis.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//   //     },
//   //     {
//   //       key: "commodities",
//   //       labelKey: "menu.commodities",
//   //       path: "/commodities",
//   //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   //       resourceKey: "commodities_masters.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "commodityProducts",
//   //       labelKey: "menu.commodityProducts",
//   //       path: "/commodity-products",
//   //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   //       resourceKey: "commodity_products_masters.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "mandiFacilities",
//   //       labelKey: "menu.mandiFacilities",
//   //       path: "/mandi-facilities",
//   //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   //       resourceKey: "mandi_facilities.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "mandiGates",
//   //       labelKey: "menu.mandiGates",
//   //       path: "/mandi-gates",
//   //       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   //       resourceKey: "mandi_gates.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//   //     },
//   //     {
//   //       key: "mandiHours",
//   //       labelKey: "menu.mandiHoursTemplates",
//   //       path: "/mandi-hours-templates",
//   //       icon: React.createElement(Inventory2OutlinedIcon),
//   //       resourceKey: "mandi_hours.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
//   //     },
//   //   ],
//   // },
//   {
//   key: "mandisGroup",
//   labelKey: "menu.mandis",
//   icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//   roles: ALL_ROLES,
//   children: [
//     {
//       key: "mandis",
//       labelKey: "menu.mandisList",  // 👈 changed
//       path: "/mandis",
//       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//       resourceKey: "mandis.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//     },
//     {
//       key: "commodities",
//       labelKey: "menu.commodities",
//       path: "/commodities",
//       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//       resourceKey: "commodities_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//     },
//     {
//       key: "commodityProducts",
//       labelKey: "menu.commodityProducts",
//       path: "/commodity-products",
//       icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//       resourceKey: "commodity_products_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//     },
//     {
//       key: "mandiFacilities",
//       labelKey: "menu.mandiFacilities",
//       path: "/mandi-facilities",
//       icon: React.createElement(Inventory2OutlinedIcon),
//       resourceKey: "mandi_facilities.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//     },
//     {
//       key: "mandiHours",
//       labelKey: "menu.mandiHoursTemplates",
//       path: "/mandi-hours-templates",
//       icon: React.createElement(Inventory2OutlinedIcon),
//       resourceKey: "mandi_hours.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR"],
//     },
//   ],
// },

//   // {
//   //   key: "gateYard",
//   //   labelKey: "menu.gateEntryReasons",
//   //   icon: React.createElement(QrCodeScannerOutlinedIcon),
//   //   roles: ALL_ROLES,
//   //   children: [
//   //     {
//   //       key: "gateEntryReasons",
//   //       labelKey: "menu.gateEntryReasons",
//   //       path: "/gate-entry-reasons",
//   //       icon: React.createElement(QrCodeScannerOutlinedIcon),
//   //       resourceKey: "gate_entry_reasons_masters.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //     {
//   //       key: "gateVehicleTypes",
//   //       labelKey: "menu.gateVehicleTypes",
//   //       path: "/gate-vehicle-types",
//   //       icon: React.createElement(QrCodeScannerOutlinedIcon),
//   //       resourceKey: "gate_vehicle_types_masters.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //     {
//   //       key: "gateDevices",
//   //       labelKey: "menu.gateDevices",
//   //       path: "/gate-devices",
//   //       icon: React.createElement(QrCodeScannerOutlinedIcon),
//   //       resourceKey: "cm_gate_devices.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //     {
//   //       key: "gateDeviceConfigs",
//   //       labelKey: "menu.gateDeviceConfigs",
//   //       path: "/gate-device-configs",
//   //       icon: React.createElement(QrCodeScannerOutlinedIcon),
//   //       resourceKey: "gate_device_configs.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //     {
//   //       key: "gateTokens",
//   //       labelKey: "menu.gateTokens",
//   //       path: "/gate-tokens",
//   //       icon: React.createElement(QrCodeScannerOutlinedIcon),
//   //       resourceKey: "gate_pass_tokens.view",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //     {
//   //       key: "gateMovements",
//   //       labelKey: "menu.gateMovements",
//   //       path: "/gate-movements",
//   //       icon: React.createElement(TimelineOutlinedIcon),
//   //       resourceKey: "gate_movements_log.view",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //     {
//   //       key: "weighmentTickets",
//   //       labelKey: "menu.weighmentTickets",
//   //       path: "/weighment-tickets",
//   //       icon: React.createElement(ScaleOutlinedIcon),
//   //       resourceKey: "weighment_tickets.view",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//   //     },
//   //   ],
//   // },

// {
//   key: "gateYard",
//   labelKey: "menu.gateYard",
//   icon: React.createElement(QrCodeScannerOutlinedIcon),
//   roles: ALL_ROLES,
//   children: [
//     {
//       key: "gateEntryReasons",
//       labelKey: "menu.gateEntryReasonsMaster",  // 👈 changed
//       path: "/gate-entry-reasons",
//       icon: React.createElement(QrCodeScannerOutlinedIcon),
//       resourceKey: "gate_entry_reasons_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "gateVehicleTypes",
//       labelKey: "menu.gateVehicleTypes",
//       path: "/gate-vehicle-types",
//       icon: React.createElement(QrCodeScannerOutlinedIcon),
//       resourceKey: "gate_vehicle_types_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "mandiGates",
//       labelKey: "menu.mandiGates",
//       path: "/mandi-gates",
//       icon: React.createElement(QrCodeScannerOutlinedIcon),
//       resourceKey: "mandi_gates.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "gateDevices",
//       labelKey: "menu.gateDevices",
//       path: "/gate-devices",
//       icon: React.createElement(QrCodeScannerOutlinedIcon),
//       resourceKey: "cm_gate_devices.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "gateDeviceConfigs",
//       labelKey: "menu.gateDeviceConfigs",
//       path: "/gate-device-configs",
//       icon: React.createElement(QrCodeScannerOutlinedIcon),
//       resourceKey: "gate_device_configs.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "gateTokens",
//       labelKey: "menu.gateTokens",
//       path: "/gate-tokens",
//       icon: React.createElement(QrCodeScannerOutlinedIcon),
//       resourceKey: "gate_pass_tokens.view",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "GATE_OPERATOR"],
//     },
//     {
//       key: "gateEntries",
//       labelKey: "menu.gateEntries",
//       path: "/gate-entries",
//       icon: React.createElement(TimelineOutlinedIcon),
//       resourceKey: "gate_entry_tokens.list",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "GATE_OPERATOR"],
//     },
//     {
//       key: "gateMovements",
//       labelKey: "menu.gateMovements",
//       path: "/gate-movements",
//       icon: React.createElement(TimelineOutlinedIcon),
//       resourceKey: "gate_movements_log.view",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "weighmentTickets",
//       labelKey: "menu.weighmentTickets",
//       path: "/weighment-tickets",
//       icon: React.createElement(ScaleOutlinedIcon),
//       resourceKey: "weighment_tickets.view",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//   ],
// },

//   // {
//   //   key: "auctions",
//   //   labelKey: "menu.auctionMethods",
//   //   icon: React.createElement(GavelOutlinedIcon),
//   //   roles: ALL_ROLES,
//   //   children: [
//   //     {
//   //       key: "auctionMethods",
//   //       labelKey: "menu.auctionMethods",
//   //       path: "/auction-methods",
//   //       icon: React.createElement(GavelOutlinedIcon),
//   //       resourceKey: "auction_methods_masters.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//   //     },
//   //     {
//   //       key: "auctionRounds",
//   //       labelKey: "menu.auctionRounds",
//   //       path: "/auction-rounds",
//   //       icon: React.createElement(GavelOutlinedIcon),
//   //       resourceKey: "auction_rounds_masters.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//   //     },
//   //     {
//   //       key: "auctionPolicies",
//   //       labelKey: "menu.auctionPolicies",
//   //       path: "/auction-policies",
//   //       icon: React.createElement(GavelOutlinedIcon),
//   //       resourceKey: "cm_mandi_auction_policies.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//   //     },
//   //     {
//   //       key: "auctionSessions",
//   //       labelKey: "menu.auctionSessions",
//   //       path: "/auction-sessions",
//   //       icon: React.createElement(GavelOutlinedIcon),
//   //       resourceKey: "auction_sessions.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "auctionLots",
//   //       labelKey: "menu.auctionLots",
//   //       path: "/auction-lots",
//   //       icon: React.createElement(GavelOutlinedIcon),
//   //       resourceKey: "auction_lots.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
//   //     },
//   //     {
//   //       key: "auctionResults",
//   //       labelKey: "menu.auctionResults",
//   //       path: "/auction-results",
//   //       icon: React.createElement(GavelOutlinedIcon),
//   //       resourceKey: "auction_results.menu",
//   //       requiredAction: "VIEW",
//   //       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
//   //     },
//   //   ],
//   // },

// {
//   key: "auctions",
//   labelKey: "menu.auctionMethods",
//   icon: React.createElement(GavelOutlinedIcon),
//   roles: ALL_ROLES,
//   children: [
//     {
//       key: "auctionMethods",
//       labelKey: "menu.auctionMethodsMaster",  // 👈 changed
//       path: "/auction-methods",
//       icon: React.createElement(GavelOutlinedIcon),
//       resourceKey: "auction_methods_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//     },
//     {
//       key: "auctionRounds",
//       labelKey: "menu.auctionRounds",
//       path: "/auction-rounds",
//       icon: React.createElement(GavelOutlinedIcon),
//       resourceKey: "auction_rounds_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//     },
//     {
//       key: "auctionPolicies",
//       labelKey: "menu.auctionPolicies",
//       path: "/auction-policies",
//       icon: React.createElement(GavelOutlinedIcon),
//       resourceKey: "auction_policies_masters.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN"],
//     },
//     {
//       key: "auctionSessions",
//       labelKey: "menu.auctionSessions",
//       path: "/auction-sessions",
//       icon: React.createElement(GavelOutlinedIcon),
//       resourceKey: "auction_sessions.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUCTIONEER", "AUDITOR"],
//     },
//     {
//       key: "auctionLots",
//       labelKey: "menu.auctionLots",
//       path: "/auction-lots",
//       icon: React.createElement(GavelOutlinedIcon),
//       resourceKey: "auction_lots.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUCTIONEER", "AUDITOR"],
//     },
//     {
//       key: "auctionResults",
//       labelKey: "menu.auctionResults",
//       path: "/auction-results",
//       icon: React.createElement(GavelOutlinedIcon),
//       resourceKey: "auction_results.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "AUDITOR"],
//     },
//   ],
// },




// {
//   key: "parties",
//   labelKey: "menu.traderApprovals",
//   icon: React.createElement(TaskAltOutlinedIcon),
//   roles: ALL_ROLES,
//   children: [
//     {
//       key: "traderApprovals",
//       labelKey: "menu.traderMembershipApprovals",
//       path: "/trader-approvals",
//       icon: React.createElement(TaskAltOutlinedIcon),
//       resourceKey: "trader_approvals.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN"],
//     },
//     {
//       key: "traders",
//       labelKey: "menu.traders",
//       path: "/traders",
//       icon: React.createElement(BadgeOutlinedIcon),
//       resourceKey: "traders.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "ORG_VIEWER", "AUDITOR"],
//     },
//     {
//       key: "farmers",
//       labelKey: "menu.farmers",
//       path: "/farmers",
//       icon: React.createElement(BadgeOutlinedIcon),
//       resourceKey: "farmers.menu",
//       requiredAction: "VIEW",
//       roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "ORG_VIEWER", "AUDITOR"],
//     },
//   ],
// },



//   {
//     key: "payments",
//     labelKey: "menu.paymentsAndSettlements",
//     icon: React.createElement(AccountBalanceWalletOutlinedIcon),
//     roles: ALL_ROLES,
//     children: [
//       {
//         key: "paymentModels",
//         labelKey: "menu.paymentModels",
//         path: "/payment-models",
//         icon: React.createElement(AccountBalanceWalletOutlinedIcon),
//         resourceKey: "payment_models.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "orgPaymentSettings",
//         labelKey: "menu.orgPaymentSettings",
//         path: "/org-payment-settings",
//         icon: React.createElement(AccountBalanceOutlinedIcon),
//         resourceKey: "org_payment_settings.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "mandiPaymentSettings",
//         labelKey: "menu.mandiPaymentSettings",
//         path: "/mandi-payment-settings",
//         icon: React.createElement(StoreMallDirectoryOutlinedIcon),
//         resourceKey: "mandi_payment_settings.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "commodityFees",
//         labelKey: "menu.commodityFeeSettings",
//         path: "/commodity-fees",
//         icon: React.createElement(Inventory2OutlinedIcon),
//         resourceKey: "commodity_fees.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "paymentModes",
//         labelKey: "menu.paymentModes",
//         path: "/payment-modes",
//         icon: React.createElement(SettingsOutlinedIcon),
//         resourceKey: "payment_modes.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "customFees",
//         labelKey: "menu.customFees",
//         path: "/custom-fees",
//         icon: React.createElement(ReceiptLongOutlinedIcon),
//         resourceKey: "custom_fees.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "roleCustomFees",
//         labelKey: "menu.roleCustomFees",
//         path: "/role-custom-fees",
//         icon: React.createElement(GroupsOutlinedIcon),
//         resourceKey: "role_custom_fees.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "subscriptions",
//         labelKey: "menu.subscriptions",
//         path: "/subscriptions",
//         icon: React.createElement(AccountBalanceOutlinedIcon),
//         resourceKey: "subscriptions.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "subscriptionInvoices",
//         labelKey: "menu.subscriptionInvoices",
//         path: "/subscription-invoices",
//         icon: React.createElement(ReceiptLongOutlinedIcon),
//         resourceKey: "subscription_invoices.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "settlements",
//         labelKey: "menu.settlements",
//         path: "/settlements",
//         icon: React.createElement(AssessmentOutlinedIcon),
//         resourceKey: "settlements.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//       {
//         key: "paymentsLog",
//         labelKey: "menu.paymentsLog",
//         path: "/payments-log",
//         icon: React.createElement(ReceiptLongOutlinedIcon),
//         resourceKey: "payments_log.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "MANDI_ADMIN", "MANDI_MANAGER"],
//       },
//     ],
//   },




//   {
//     key: "reports",
//     labelKey: "menu.reports",
//     icon: React.createElement(MapOutlinedIcon),
//     roles: ALL_ROLES,
//     children: [
//       {
//         key: "mandiCoverage",
//         labelKey: "menu.mandiCoverage",
//         path: "/mandi-coverage",
//         icon: React.createElement(MapOutlinedIcon),
//         resourceKey: "mandi_coverage.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "MANDI_ADMIN", "MANDI_MANAGER", "AUDITOR", "VIEWER"],
//       },
//       {
//         key: "mandiPrices",
//         labelKey: "menu.mandiPrices",
//         path: "/mandi-prices",
//         icon: React.createElement(PriceChangeOutlinedIcon),
//         resourceKey: "mandi_prices.menu",
//         requiredAction: "VIEW",
//         roles: ["SUPER_ADMIN", "ORG_ADMIN", "ORG_VIEWER", "MANDI_ADMIN", "MANDI_MANAGER", "AUCTIONEER", "AUDITOR", "VIEWER"],
//       },
//     ],
//   },
// ];

// function cloneMenuItem(item: AppMenuItem, overrides: Partial<AppMenuItem> = {}): AppMenuItem {
//   return {
//     ...item,
//     ...overrides,
//   };
// }

// function filterHierarchy(
//   items: AppMenuItem[],
//   predicate: (item: AppMenuItem, hasChildren: boolean) => boolean,
// ): AppMenuItem[] {
//   const results: AppMenuItem[] = [];
//   for (const item of items) {
//     const filteredChildren = item.children ? filterHierarchy(item.children, predicate) : [];
//     const hasChildren = filteredChildren.length > 0;
//     const visible = predicate(item, hasChildren) || hasChildren;
//     if (visible) {
//       const node: AppMenuItem = cloneMenuItem(item, {
//         children: filteredChildren.length ? filteredChildren : undefined,
//       });
//       results.push(node);
//     }
//   }
//   return results;
// }

// export type MenuItem = AppMenuItem;

// export function filterMenuByRole(role: RoleSlug | null) {
//   const knownRole = role && ALL_ROLES.includes(role);
//   const effectiveRole: RoleSlug = knownRole ? role : "VIEWER";

//   if (!knownRole) {
//     console.warn(
//       "[menuConfig/filterMenuByRole] Unknown or missing role; using VIEWER fallback.",
//       { inputRole: role },
//     );
//   }

//   return filterHierarchy(APP_MENU, (item, hasChildren) => {
//     // For group containers without their own permission role check, hide if no visible children.
//     if (!item.path && !item.resourceKey && !hasChildren) return false;
//     if (!item.roles || item.roles.length === 0) return true;
//     return item.roles.includes(effectiveRole);
//   });
// }

// const normalizeKey = (key?: string | null) => {
//   if (!key) return "";
//   return String(key).trim().replace(/\s+/g, "").replace(/_{2,}/g, "_").toLowerCase();
// };

// export function filterMenuByResources(
//   resources: UiResource[] | undefined,
//   fallbackRole: RoleSlug | null,
//   permissionsMap?: Record<string, Set<string>>,
// ) {
//   try {
//     const hasResources = Array.isArray(resources) && resources.length > 0;
//     if (!hasResources) {
//       return [];
//     }
//     const hasPermissions =
//       permissionsMap && Object.keys(permissionsMap).length > 0;
//     // If permissions have not been loaded yet, do not render a temporary menu –
//     // this avoids the “full menu then collapse” flicker for limited roles.
//     if (!hasPermissions) {
//       return [];
//     }

//     let excludedNoRoute = 0;
//     let excludedNoGroup = 0;
