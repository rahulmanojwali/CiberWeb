import AdminUsersList from "../admin-users/AdminUsersList";
export const AdminUsers: React.FC = () => <AdminUsersList />;
