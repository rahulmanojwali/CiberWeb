import React, { useEffect, useMemo, useState } from "react";
import { Box, Button, MenuItem, Stack, TextField, Typography } from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import { type GridColDef } from "@mui/x-data-grid";
import { useTranslation } from "react-i18next";
import { PageContainer } from "../../components/PageContainer";
import { ResponsiveDataGrid } from "../../components/ResponsiveDataGrid";
import { normalizeLanguageCode } from "../../config/languages";
import { useAdminUiConfig } from "../../contexts/admin-ui-config";
import { can } from "../../utils/adminUiConfig";
import { fetchOrganisations } from "../../services/adminUsersApi";
import { fetchMandis } from "../../services/mandiApi";
import { getAuctionResults, listAuctionResultsBySession } from "../../services/auctionOpsApi";
import { subscribeAuctionSession } from "../../services/socketClient";

type ResultRow = {
  id: string;
  result_id: string;
  session_id?: string | null;
  lot_id?: string | null;
  org_code?: string | null;
  mandi_code?: string | null;
  commodity?: string | null;
  product?: string | null;
  winning_trader?: string | null;
  price?: string | null;
  quantity?: number | null;
  status?: string | null;
  result_time?: string | null;
};

type Option = { value: string; label: string };

function currentUsername(): string | null {
  try {
    const raw = localStorage.getItem("cd_user");
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed?.username || null;
  } catch {
    return null;
  }
}

function formatDate(value?: string | Date | null) {
  if (!value) return "";
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString();
}

export const AuctionResults: React.FC = () => {
  const { t, i18n } = useTranslation();
  const language = normalizeLanguageCode(i18n.language);
  const uiConfig = useAdminUiConfig();

  const [filters, setFilters] = useState({
    org_code: "",
    mandi_code: "",
    commodity: "",
    product: "",
    session_id: "",
    lot_id: "",
    result_status: "",
    date_from: "",
    date_to: "",
  });
  const [rows, setRows] = useState<ResultRow[]>([]);
  const [orgOptions, setOrgOptions] = useState<Option[]>([]);
  const [mandiOptions, setMandiOptions] = useState<Option[]>([]);
  const [loading, setLoading] = useState(false);

  const canMenu = useMemo(
    () => can(uiConfig.resources, "auction_results.menu", "VIEW") || can(uiConfig.resources, "auction_results.view", "VIEW"),
    [uiConfig.resources],
  );
  const canView = useMemo(() => can(uiConfig.resources, "auction_results.view", "VIEW"), [uiConfig.resources]);

  const columns = useMemo<GridColDef<ResultRow>[]>(
    () => [
      { field: "result_id", headerName: "Result ID", width: 140 },
      { field: "session_id", headerName: "Session", width: 140 },
      { field: "lot_id", headerName: "Lot", width: 140 },
      { field: "org_code", headerName: "Org", width: 110 },
      { field: "mandi_code", headerName: "Mandi", width: 140 },
      { field: "commodity", headerName: "Commodity", width: 140 },
      { field: "product", headerName: "Product", width: 140 },
      { field: "winning_trader", headerName: "Winning Trader", width: 170 },
      { field: "price", headerName: "Price", width: 130 },
      { field: "quantity", headerName: "Qty", width: 110 },
      { field: "status", headerName: "Status", width: 140 },
      {
        field: "result_time",
        headerName: "Timestamp",
        width: 180,
        valueFormatter: (value) => formatDate(value),
      },
    ],
    [],
  );

  const loadOrganisations = async () => {
    if (uiConfig.role !== "SUPER_ADMIN") return;
    const username = currentUsername();
    if (!username) return;
    const resp = await fetchOrganisations({ username, language });
    const list = resp?.data?.organisations || resp?.response?.data?.organisations || [];
    setOrgOptions(
      list.map((org: any) => ({
        value: org.org_code || org._id || "",
        label: org.org_name ? `${org.org_name} (${org.org_code || org._id})` : org.org_code || org._id,
      })),
    );
  };

  const loadMandis = async () => {
    const username = currentUsername();
    if (!username) return;
    const resp = await fetchMandis({ username, language, filters: { is_active: true } });
    const list = resp?.data?.mandis || resp?.response?.data?.mandis || [];
    setMandiOptions(
      list.map((m: any) => ({
        value: m.mandi_slug || m.slug || String(m.mandi_id || ""),
        label: m?.name_i18n?.en || m.mandi_slug || String(m.mandi_id),
      })),
    );
  };

  const loadData = async () => {
    const username = currentUsername();
    if (!username || !canView) return;
    setLoading(true);
    try {
      const resp = filters.session_id
        ? await listAuctionResultsBySession({
            username,
            language,
            payload: {
              org_id: uiConfig.scope?.org_id || undefined,
              mandi_id: filters.mandi_code || undefined,
              session_id: filters.session_id,
              status: filters.result_status || undefined,
              page_size: 100,
            },
          })
        : await getAuctionResults({
            username,
            language,
            filters: {
              org_code: filters.org_code || undefined,
              mandi_code: filters.mandi_code || undefined,
              commodity: filters.commodity || undefined,
              product: filters.product || undefined,
              lot_id: filters.lot_id || undefined,
              result_status: filters.result_status || undefined,
              date_from: filters.date_from || undefined,
              date_to: filters.date_to || undefined,
              page_size: 100,
            },
          });
      const list = resp?.data?.items || resp?.response?.data?.items || [];
      const mapped: ResultRow[] = list.map((item: any, idx: number) => ({
        id: item._id || item.result_id || `result-${idx}`,
        result_id: item.result_id || item._id || `result-${idx}`,
        session_id: item.session_id || null,
        lot_id: item.lot_id || null,
        org_code: item.org_code || null,
        mandi_code: item.mandi_code || null,
        commodity: item.commodity_name_en || item.commodity || item.commodity_code || null,
        product: item.product_name_en || item.product || item.product_code || null,
        winning_trader: item.winner_code || item.winning_trader || item.trader || null,
        price: item.final_price_per_qtl ?? item.price ?? item.winning_price ?? null,
        quantity: item.quantity ?? item.estimated_qty_kg ?? null,
        status: item.status || null,
        result_time: item.updated_on || item.created_on || item.result_time || item.timestamp || null,
      }));
      setRows(mapped);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrganisations();
    loadMandis();
  }, [language, uiConfig.role]);

  useEffect(() => {
    loadData();
  }, [filters.org_code, filters.mandi_code, filters.commodity, filters.product, filters.session_id, filters.lot_id, filters.result_status, filters.date_from, filters.date_to, language, canView]);

  useEffect(() => {
    if (!canView || !filters.session_id) return;
    let unsubscribe: null | (() => void) = null;
    const reload = (payload: any) => {
      if (!payload?.session_id || String(payload.session_id) !== String(filters.session_id)) return;
      void loadData();
    };
    subscribeAuctionSession(
      { sessionId: filters.session_id, mandiId: filters.mandi_code || undefined },
      {
        "auction.result.finalized": reload,
        "auction.session.updated": reload,
        "auction.lot.updated": reload,
      }
    ).then((cleanup) => {
      unsubscribe = cleanup;
    }).catch((err) => {
      if (import.meta.env.DEV) console.debug("[auctionResults] realtime subscribe failed", err);
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [canView, filters.session_id, filters.mandi_code, language]);

  const updateFilter = (key: keyof typeof filters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  if (!canMenu || !canView) {
    return (
      <PageContainer>
        <Typography variant="h6">Not authorized to view auction results.</Typography>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={2} mb={2}>
        <Stack spacing={0.5}>
          <Typography variant="h5">{t("menu.auctionResults", { defaultValue: "Auction Results" })}</Typography>
          <Typography variant="body2" color="text.secondary">
            Final auction results and winners. Use session filter for the stable session-scoped result feed.
          </Typography>
        </Stack>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadData} disabled={loading}>
          Refresh
        </Button>
      </Stack>

      <Stack
        direction={{ xs: "column", md: "row" }}
        spacing={2}
        mb={2}
        alignItems={{ xs: "flex-start", md: "center" }}
        flexWrap="wrap"
      >
        {uiConfig.role === "SUPER_ADMIN" && (
          <TextField
            select
            label="Organisation"
            size="small"
            sx={{ minWidth: 200 }}
            value={filters.org_code}
            onChange={(e) => updateFilter("org_code", e.target.value)}
          >
            <MenuItem value="">All</MenuItem>
            {orgOptions.map((o) => (
              <MenuItem key={o.value} value={o.value}>
                {o.label}
              </MenuItem>
            ))}
          </TextField>
        )}

        <TextField
          select
          label="Mandi"
          size="small"
          sx={{ minWidth: 180 }}
          value={filters.mandi_code}
          onChange={(e) => updateFilter("mandi_code", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          {mandiOptions.map((m) => (
            <MenuItem key={m.value} value={m.value}>
              {m.label}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="Session ID"
          size="small"
          value={filters.session_id}
          onChange={(e) => updateFilter("session_id", e.target.value)}
        />

        <TextField
          label="Lot ID"
          size="small"
          value={filters.lot_id}
          onChange={(e) => updateFilter("lot_id", e.target.value)}
        />

        <TextField
          label="Commodity"
          size="small"
          value={filters.commodity}
          onChange={(e) => updateFilter("commodity", e.target.value)}
        />

        <TextField
          label="Product"
          size="small"
          value={filters.product}
          onChange={(e) => updateFilter("product", e.target.value)}
        />

        <TextField
          select
          label="Result Status"
          size="small"
          sx={{ minWidth: 150 }}
          value={filters.result_status}
          onChange={(e) => updateFilter("result_status", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value="CONFIRMED">Confirmed</MenuItem>
          <MenuItem value="CANCELLED">Cancelled</MenuItem>
        </TextField>

        <TextField
          label="Date From"
          type="date"
          size="small"
          value={filters.date_from}
          onChange={(e) => updateFilter("date_from", e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <TextField
          label="Date To"
          type="date"
          size="small"
          value={filters.date_to}
          onChange={(e) => updateFilter("date_to", e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
      </Stack>

      <Box sx={{ width: "100%" }}>
        <ResponsiveDataGrid
          rows={rows}
          columns={columns}
          loading={loading}
          getRowId={(r) => r.id}
          disableRowSelectionOnClick
          pageSizeOptions={[25, 50, 100]}
          initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
          minWidth={960}
        />
      </Box>
    </PageContainer>
  );
};
