import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";
import StorefrontIcon from "@mui/icons-material/Storefront";
import QrCodeScannerOutlinedIcon from "@mui/icons-material/QrCodeScannerOutlined";
import ConfirmationNumberOutlinedIcon from "@mui/icons-material/ConfirmationNumberOutlined";
import { type GridColDef } from "@mui/x-data-grid";
import { useTranslation } from "react-i18next";
import { PageContainer } from "../../components/PageContainer";
import { ResponsiveDataGrid } from "../../components/ResponsiveDataGrid";
import { CMActionButton } from "../../components/ui/CMActionButton";
import { CMDataTable } from "../../components/ui/CMDataTable";
import { CMFilterCard } from "../../components/ui/CMFilterCard";
import { CMFilterField } from "../../components/ui/CMFilterField";
import { normalizeLanguageCode } from "../../config/languages";
import { useAdminUiConfig } from "../../contexts/admin-ui-config";
import { can } from "../../utils/adminUiConfig";
import { fetchOrganisations } from "../../services/adminUsersApi";
import { fetchGateMovements } from "../../services/gateOpsApi";
import { fetchMandiGates, getMandisForCurrentScope } from "../../services/mandiApi";
import { formatBusinessDateTime } from "../../utils/formatters";

type MovementRow = {
  id: string;
  token_code: string;
  mandi: string | number | null;
  gate: string | null;
  movement_type: string | null;
  actor: string | null;
  event_time?: string | null;
  raw?: any;
};

type Option = { value: string; label: string };

function currentUsername(): string | null {
  try {
    const raw = localStorage.getItem("cd_user");
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed?.username || null;
  } catch {
    return null;
  }
}

function formatDate(value?: string | Date | null) {
  return formatBusinessDateTime(value);
}

export const GateMovements: React.FC = () => {
  const { t, i18n } = useTranslation();
  const language = normalizeLanguageCode(i18n.language);
  const uiConfig = useAdminUiConfig();
  const isSuperAdmin = uiConfig.role === "SUPER_ADMIN";
  const scopedOrgId = uiConfig.scope?.org_id || "";

  const [rows, setRows] = useState<MovementRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [orgOptions, setOrgOptions] = useState<Option[]>([]);
  const [mandiOptions, setMandiOptions] = useState<Option[]>([]);
  const [mandiNameMap, setMandiNameMap] = useState<Map<number, string>>(new Map());
  const [gateOptions, setGateOptions] = useState<Option[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [selectedRow, setSelectedRow] = useState<MovementRow | null>(null);

  const [filters, setFilters] = useState({
    org_id: "",
    mandi_id: "",
    gate_code: "",
    token_code: "",
    token_id: "",
    date_from: "",
    date_to: "",
  });

  const canView = useMemo(
    () => can(uiConfig.resources, "gate_movements_log.view", "VIEW"),
    [uiConfig.resources],
  );

  const columns = useMemo<GridColDef<MovementRow>[]>(
    () => [
      { field: "token_code", headerName: "Token Code", width: 180 },
      { field: "mandi", headerName: "Mandi", width: 160 },
      { field: "gate", headerName: "Gate", width: 140 },
      { field: "movement_type", headerName: "Movement", width: 160 },
      { field: "actor", headerName: "Actor / Source", width: 180 },
      {
        field: "event_time",
        headerName: "Timestamp",
        width: 200,
        valueFormatter: (value) => formatDate(value),
      },
      {
        field: "details",
        headerName: "Details",
        width: 120,
        sortable: false,
        renderCell: (params) => (
          <Button size="small" onClick={() => setSelectedRow(params.row)}>
            View
          </Button>
        ),
      },
    ],
    [],
  );

  const loadOrganisations = async () => {
    if (!isSuperAdmin) return;
    const username = currentUsername();
    if (!username) return;
    const resp = await fetchOrganisations({ username, language });
    const list = resp?.data?.organisations || resp?.response?.data?.organisations || [];
    setOrgOptions(
      list.map((org: any) => ({
        value: org._id || org.org_id || org.org_code,
        label: org.org_name ? `${org.org_name} (${org.org_code || org._id})` : org.org_code || org._id,
      })),
    );
  };

  const loadMandis = async () => {
    const username = currentUsername();
    if (!username) return;
    const orgId = filters.org_id;
    if (!orgId) {
      setMandiOptions([]);
      setMandiNameMap(new Map());
      return;
    }
    try {
      const list = await getMandisForCurrentScope({
        username,
        language,
        org_id: orgId,
        filters: {
          page: 1,
          pageSize: 200,
        },
      });
      const nextMap = new Map<number, string>();
      list.forEach((m: any) => {
        const id = Number(m.mandi_id);
        if (!Number.isNaN(id)) {
          const label = m?.name_i18n?.[language] || m?.name_i18n?.en || m?.label || m?.mandi_slug || String(id);
          nextMap.set(id, label);
        }
      });
      setMandiOptions(
        list.map((m: any) => ({
          value: String(m.mandi_id || m.slug || m.mandi_slug || ""),
          label: m?.name_i18n?.[language] || m?.name_i18n?.en || m?.label || m.mandi_slug || String(m.mandi_id),
        })),
      );
      setMandiNameMap(nextMap);
    } catch (err) {
      console.error("[GateMovements] loadMandis error", err);
      setMandiOptions([]);
      setMandiNameMap(new Map());
    }
  };

  const loadGates = async (mandiId?: string) => {
    const username = currentUsername();
    if (!username || !mandiId) {
      setGateOptions([]);
      return;
    }
    const resp = await fetchMandiGates({
      username,
      language,
      filters: { mandi_id: Number(mandiId), is_active: "Y" },
    });
    const list = resp?.data?.items || resp?.response?.data?.items || [];
    setGateOptions(
      list.map((g: any) => ({
        value: g.gate_code || g.code || g.slug || "",
        label: g.gate_name || g.gate_code || g.code || g.slug || "",
      })),
    );
  };

  const loadData = async () => {
    const username = currentUsername();
    if (!username || !canView) return;
    setLoading(true);
    try {
      const resp = await fetchGateMovements({
        username,
        language,
        filters: {
          org_id: filters.org_id || undefined,
          mandi_id: filters.mandi_id ? Number(filters.mandi_id) : undefined,
          gate: filters.gate_code || undefined,
          gate_code: filters.gate_code || undefined,
          token_code: filters.token_code || undefined,
          token_id: filters.token_id || undefined,
          date_from: filters.date_from || undefined,
          date_to: filters.date_to || undefined,
          page_size: 100,
        },
      });

      const list = resp?.data?.items || resp?.response?.data?.items || [];
      const total = resp?.data?.total_records ?? resp?.response?.data?.total_records;

      const mapped: MovementRow[] = list.map((item: any, idx: number) => ({
        id: item._id || `${item.details?.token_code || item.token_code || "movement"}-${idx}`,
        token_code: item.details?.token_code || item.token_code || item.token_id || `token-${idx}`,
        mandi:
          item.mandi_name ||
          mandiNameMap.get(Number(item.mandi_id)) ||
          item.mandi ||
          item.mandi_slug ||
          item.mandi_id ||
          null,
        gate: item.gate_code || item.gate || null,
        movement_type:
          item.step ||
          item.details?.step ||
          item.movement_type ||
          item.event ||
          item.event_type ||
          item.action ||
          "-",
        actor: item.actor || item.source || item.performed_by || item.username || null,
        event_time: item.ts || item.event_time || item.created_on || item.createdAt || null,
        raw: item,
      }));

      mapped.sort((a, b) => {
        const ad = a.event_time || "";
        const bd = b.event_time || "";
        return new Date(bd).getTime() - new Date(ad).getTime();
      });

      setRows(mapped);
      setTotalCount(typeof total === "number" ? total : mapped.length);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrganisations();
  }, [language, isSuperAdmin]);

  useEffect(() => {
    if (isSuperAdmin) return;
    if (!scopedOrgId) return;
    if (filters.org_id === scopedOrgId) return;
    setFilters((prev) => ({
      ...prev,
      org_id: scopedOrgId,
      mandi_id: "",
      gate_code: "",
    }));
  }, [isSuperAdmin, scopedOrgId, filters.org_id]);

  useEffect(() => {
    if (!filters.org_id) {
      setMandiOptions([]);
      return;
    }
    loadMandis();
  }, [filters.org_id, language]);

  useEffect(() => {
    loadGates(filters.mandi_id);
  }, [filters.mandi_id, language]);

  useEffect(() => {
    if (!mandiOptions.length) return;
    if (filters.mandi_id) return;
    if (mandiOptions.length === 1) {
      setFilters((prev) => ({ ...prev, mandi_id: mandiOptions[0].value }));
    }
  }, [mandiOptions, filters.mandi_id]);

  useEffect(() => {
    loadData();
  }, [
    filters.org_id,
    filters.mandi_id,
    filters.gate_code,
    filters.token_code,
    filters.token_id,
    filters.date_from,
    filters.date_to,
    language,
    canView,
  ]);

  const updateFilter = (key: keyof typeof filters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  if (!canView) {
    return (
      <PageContainer>
        <Typography variant="h6">Not authorized to view gate movements.</Typography>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={2} mb={2}>
        <Stack spacing={0.5}>
          <Typography variant="h5">{t("menu.gateMovements", { defaultValue: "Gate Entry Movements" })}</Typography>
          <Typography variant="body2" color="text.secondary">
            Live movement log from gates and devices (read-only).
          </Typography>
        </Stack>
        <CMActionButton variant="outlined" startIcon={<RefreshIcon />} onClick={loadData} disabled={loading}>
          Refresh
        </CMActionButton>
      </Stack>

      <CMFilterCard
        actions={<CMActionButton variant="contained" onClick={loadData} disabled={loading}>Apply Filters</CMActionButton>}
      >
      <Box className="cm-filter-row">
        {uiConfig.role === "SUPER_ADMIN" && (
          <CMFilterField
            select
            label="Organisation"
            icon={BusinessOutlinedIcon}
            value={filters.org_id}
            onChange={(e) => updateFilter("org_id", e.target.value)}
          >
            <MenuItem value="">All</MenuItem>
            {orgOptions.map((o) => (
              <MenuItem key={o.value} value={o.value}>
                {o.label}
              </MenuItem>
            ))}
          </CMFilterField>
        )}

        <CMFilterField
          select
          label="Mandi"
          icon={StorefrontIcon}
          value={filters.mandi_id}
          onChange={(e) => updateFilter("mandi_id", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          {mandiOptions.map((m) => (
            <MenuItem key={m.value} value={m.value}>
              {m.label}
            </MenuItem>
          ))}
        </CMFilterField>

        <CMFilterField
          select
          label="Gate"
          icon={StorefrontIcon}
          value={filters.gate_code}
          onChange={(e) => updateFilter("gate_code", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          {gateOptions.map((g) => (
            <MenuItem key={g.value} value={g.value}>
              {g.label}
            </MenuItem>
          ))}
        </CMFilterField>

        <CMFilterField
          label="Token Code"
          icon={QrCodeScannerOutlinedIcon}
          value={filters.token_code}
          onChange={(e) => updateFilter("token_code", e.target.value)}
        />
      </Box>

      <Box className="cm-filter-row">
        <CMFilterField
          label="Token ID"
          icon={ConfirmationNumberOutlinedIcon}
          value={filters.token_id}
          onChange={(e) => updateFilter("token_id", e.target.value)}
        />

        <CMFilterField
          label="Date From"
          type="date"
          value={filters.date_from}
          onChange={(e) => updateFilter("date_from", e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <CMFilterField
          label="Date To"
          type="date"
          value={filters.date_to}
          onChange={(e) => updateFilter("date_to", e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <Box className="cm-filter-actions-inline">
          <span className="cm-filter-record-count">Showing {rows.length} records{totalCount ? ` (server total: ${totalCount})` : ""}</span>
        </Box>
      </Box>
      </CMFilterCard>

      <Box sx={{ width: "100%" }}>
        <CMDataTable
          rows={rows}
          columns={columns}
          loading={loading}
          getRowId={(r) => r.id || r.token_code}
          pageSizeOptions={[25, 50, 100]}
          initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
          minWidth={960}
        />
      </Box>
      <Dialog open={!!selectedRow} onClose={() => setSelectedRow(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Movement Details</DialogTitle>
        <DialogContent dividers>
          <Stack spacing={1}>
            <Typography variant="body2">Token Code: {selectedRow?.raw?.details?.token_code || "-"}</Typography>
            <Typography variant="body2">Step: {selectedRow?.raw?.step || selectedRow?.raw?.details?.step || "-"}</Typography>
            <Typography variant="body2">Gate: {selectedRow?.raw?.gate_code || "-"}</Typography>
            <Typography variant="body2">Actor: {selectedRow?.raw?.actor || "-"}</Typography>
            <Typography variant="body2">Timestamp: {formatDate(selectedRow?.raw?.ts)}</Typography>
            <Typography variant="body2">Device: {selectedRow?.raw?.details?.device_code || "-"}</Typography>
            <Typography variant="body2">Vehicle No: {selectedRow?.raw?.details?.vehicle_no || "-"}</Typography>
            <Typography variant="body2">Vehicle Type: {selectedRow?.raw?.details?.vehicle_type_code || "-"}</Typography>
            <Typography variant="body2">Reason: {selectedRow?.raw?.details?.reason_code || "-"}</Typography>
            <Typography variant="body2">Party Type: {selectedRow?.raw?.details?.party_type || "-"}</Typography>
            <Typography variant="body2">Party Ref: {selectedRow?.raw?.details?.party_ref || "-"}</Typography>
            <Typography variant="body2">Remarks: {selectedRow?.raw?.details?.remarks || "-"}</Typography>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSelectedRow(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </PageContainer>
  );
};
