import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  Chip,
  MenuItem,
  Stack,
  Card,
  CardContent,
  CardActions,
  TextField,
  Typography,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import { type GridColDef } from "@mui/x-data-grid";
import { useTranslation } from "react-i18next";
import { useTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useNavigate } from "react-router-dom";
import { PageContainer } from "../../components/PageContainer";
import { ResponsiveDataGrid } from "../../components/ResponsiveDataGrid";
import { normalizeLanguageCode } from "../../config/languages";
import { useAdminUiConfig } from "../../contexts/admin-ui-config";
import { fetchOrganisations } from "../../services/adminUsersApi";
import { fetchGatePassTokens, fetchGateEntryTokens } from "../../services/gateOpsApi";
import { fetchMandiGates, getMandisForCurrentScope } from "../../services/mandiApi";
import { usePermissions } from "../../authz/usePermissions";

type TokenRow = {
  id: string;
  token_code: string;
  token_type: "PASS" | "ENTRY";
  mandi: string | number | null;
  gate_code: string | null;
  device_code?: string | null;
  vehicle_no?: string | null;
  reason_code?: string | null;
  status: string | null;
  last_step?: string | null;
  created_on?: string | null;
  updated_on?: string | null;
  updated_by?: string | null;
};

type Option = { value: string; label: string };

function currentUsername(): string | null {
  try {
    const raw = localStorage.getItem("cd_user");
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed?.username || null;
  } catch {
    return null;
  }
}

function formatDate(value?: string | Date | null) {
  if (!value) return "";
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString();
}

export const GateTokens: React.FC = () => {
  const { t, i18n } = useTranslation();
  const language = normalizeLanguageCode(i18n.language);
  const uiConfig = useAdminUiConfig();
  const { can, permissionsMap } = usePermissions();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const navigate = useNavigate();

  const [rows, setRows] = useState<TokenRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [orgOptions, setOrgOptions] = useState<Option[]>([]);
  const [mandiOptions, setMandiOptions] = useState<Option[]>([]);
  const [gateOptions, setGateOptions] = useState<Option[]>([]);
  const [totalCount, setTotalCount] = useState(0);

  const [filters, setFilters] = useState({
    org_id: "",
    mandi_id: "",
    gate_code: "",
    token_type: "ALL" as "ALL" | "PASS" | "ENTRY",
    status: "",
    date_from: "",
    date_to: "",
  });

  const canViewPass = useMemo(
    () => can("gate_pass_tokens.view", "VIEW"),
    [can],
  );
  const canViewEntry = useMemo(
    () => can("gate_entry_tokens.list", "VIEW"),
    [can],
  );
  const canCreateEntry = useMemo(
    () => can("gate_entry_tokens.create", "CREATE"),
    [can],
  );
  const canUpdateEntry = useMemo(
    () => can("gate_entry_tokens.update", "UPDATE"),
    [can],
  );
  const canCreatePass = useMemo(
    () => can("gate_pass_tokens.create", "CREATE"),
    [can],
  );
  const isDebug = new URLSearchParams(window.location.search).get("debugAuth") === "1";

  useEffect(() => {
    setFilters((prev) => {
      if (prev.token_type === "PASS" && !canViewPass && canViewEntry) {
        return { ...prev, token_type: "ENTRY" };
      }
      if (prev.token_type === "ENTRY" && !canViewEntry && canViewPass) {
        return { ...prev, token_type: "PASS" };
      }
      if (prev.token_type === "ALL") {
        if (!canViewPass && canViewEntry) return { ...prev, token_type: "ENTRY" };
        if (!canViewEntry && canViewPass) return { ...prev, token_type: "PASS" };
      }
      return prev;
    });
  }, [canViewPass, canViewEntry]);

  const tokenTypeOptions = useMemo(() => {
    const opts: Option[] = [];
    if (canViewPass && canViewEntry) opts.push({ value: "ALL", label: "All" });
    if (canViewPass) opts.push({ value: "PASS", label: "Pass Tokens" });
    if (canViewEntry) opts.push({ value: "ENTRY", label: "Entry Tokens" });
    return opts;
  }, [canViewEntry, canViewPass]);

  const columns = useMemo<GridColDef<TokenRow>[]>(
    () => [
      { field: "token_code", headerName: "Token Code", width: 180 },
      { field: "token_type", headerName: "Type", width: 110 },
      { field: "vehicle_no", headerName: "Vehicle", width: 140 },
      { field: "reason_code", headerName: "Reason", width: 150 },
      { field: "gate_code", headerName: "Gate", width: 120 },
      { field: "device_code", headerName: "Device", width: 140 },
      { field: "last_step", headerName: "Last Step", width: 130 },
      {
        field: "status",
        headerName: "Status",
        width: 140,
        renderCell: (params) => (
          <Chip
            size="small"
            label={params.value || "-"}
            color={
              params.value === "IN_YARD"
                ? "success"
                : params.value === "ISSUED"
                  ? "info"
                  : params.value === "EXITED"
                    ? "default"
                    : "default"
            }
          />
        ),
      },
      {
        field: "created_on",
        headerName: "Created On",
        width: 190,
        valueFormatter: (value) => formatDate(value),
      },
      {
        field: "updated_on",
        headerName: "Updated On",
        width: 190,
        valueFormatter: (value) => formatDate(value),
      },
      { field: "updated_by", headerName: "Updated By", width: 140 },
      {
        field: "actions",
        headerName: "Actions",
        sortable: false,
        filterable: false,
        width: 200,
        renderCell: (params) => (
          <Stack direction="row" spacing={1}>
            <Button
              size="small"
              startIcon={<VisibilityOutlinedIcon fontSize="small" />}
              onClick={() => navigate(`/gate-tokens/${encodeURIComponent(params.row.token_code)}`)}
            >
              View
            </Button>
            <Button size="small" onClick={() => navigate(`/gate-tokens/${encodeURIComponent(params.row.token_code)}#movements`)}>
              Movements
            </Button>
            {canUpdateEntry && params.row.token_type === "ENTRY" && (
              <Button
                size="small"
                onClick={() => navigate(`/gate-tokens/${encodeURIComponent(params.row.token_code)}?mode=edit`)}
              >
                Update
              </Button>
            )}
          </Stack>
        ),
      },
    ],
    [canUpdateEntry, navigate],
  );

  const loadOrganisations = async () => {
    if (uiConfig.role !== "SUPER_ADMIN") return;
    const username = currentUsername();
    if (!username) return;
    const resp = await fetchOrganisations({ username, language });
    const list = resp?.data?.organisations || resp?.response?.data?.organisations || [];
    setOrgOptions(
      list.map((org: any) => ({
        value: org._id || org.org_id || org.org_code,
        label: org.org_name ? `${org.org_name} (${org.org_code || org._id})` : org.org_code || org._id,
      })),
    );
  };

  const loadMandis = async () => {
    const username = currentUsername();
    if (!username) return;
    const orgId = filters.org_id;
    if (!orgId) {
      setMandiOptions([]);
      return;
    }
    try {
      const list = await getMandisForCurrentScope({
        username,
        language,
        org_id: orgId,
        filters: {
          page: 1,
          pageSize: 200,
        },
      });
      setMandiOptions(
        list.map((m: any) => ({
          value: String(m.mandi_id || m.slug || m.mandi_slug || ""),
          label: m?.name_i18n?.en || m.mandi_slug || String(m.mandi_id),
        })),
      );
    } catch (err) {
      console.error("[GateTokens] loadMandis error", err);
      setMandiOptions([]);
    }
  };

  const loadGates = async (mandiId?: string) => {
    const username = currentUsername();
    if (!username || !mandiId) {
      setGateOptions([]);
      return;
    }
    const resp = await fetchMandiGates({
      username,
      language,
      filters: { mandi_id: Number(mandiId), is_active: "Y" },
    });
    const list = resp?.data?.items || resp?.response?.data?.items || [];
    setGateOptions(
      list.map((g: any) => ({
        value: g.gate_code || g.code || g.slug || "",
        label: g.gate_name || g.gate_code || g.code || g.slug || "",
      })),
    );
  };

  const loadData = async () => {
    const username = currentUsername();
    if (!username || (!canViewPass && !canViewEntry)) return;
    setLoading(true);
    try {
      const commonFilters: Record<string, any> = {
        org_id: filters.org_id || undefined,
        mandi_id: filters.mandi_id ? Number(filters.mandi_id) : undefined,
        gate: filters.gate_code || undefined,
        gate_code: filters.gate_code || undefined,
        status: filters.status || undefined,
        date_from: filters.date_from || undefined,
        date_to: filters.date_to || undefined,
        page_size: 100,
      };

      const requests: Array<Promise<{ kind: "PASS" | "ENTRY"; payload: any }>> = [];
      if (canViewPass && filters.token_type !== "ENTRY") {
        requests.push(
          fetchGatePassTokens({ username, language, filters: commonFilters }).then((payload) => ({
            kind: "PASS",
            payload,
          })),
        );
      }
      if (canViewEntry && filters.token_type !== "PASS") {
        requests.push(
          fetchGateEntryTokens({ username, language, filters: commonFilters }).then((payload) => ({
            kind: "ENTRY",
            payload,
          })),
        );
      }

      const results = await Promise.all(requests);
      const combined: TokenRow[] = [];
      let total = 0;

      results.forEach(({ kind, payload }) => {
        const list = payload?.data?.items || payload?.response?.data?.items || [];
        const totalRecords = payload?.data?.total_records ?? payload?.response?.data?.total_records;
        if (typeof totalRecords === "number") total += totalRecords;

        list.forEach((item: any, idx: number) => {
          const code = item.token_code || item.code || `${kind}-${idx}`;
          combined.push({
            id: item._id || `${kind}-${code}-${idx}`,
            token_code: code,
            token_type: kind,
            mandi: item.mandi || item.mandi_slug || item.mandi_id || null,
            gate_code: item.gate_code || item.gate || null,
            device_code: item.device_code || null,
            vehicle_no: item.vehicle_no || null,
            reason_code: item.reason_code || item.reason || null,
            status: item.status || null,
            last_step: item.last_step || item.last_movement_step || item.movement_step || null,
            created_on: item.created_on || item.createdAt || null,
            updated_on: item.updated_on || item.updatedAt || null,
            updated_by: item.updated_by || item.updatedBy || null,
          });
        });
      });

      combined.sort((a, b) => {
        const ad = a.updated_on || a.created_on || "";
        const bd = b.updated_on || b.created_on || "";
        return new Date(bd).getTime() - new Date(ad).getTime();
      });

      setRows(combined);
      setTotalCount(total || combined.length);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrganisations();
  }, [language, uiConfig.role]);

  useEffect(() => {
    if (!filters.org_id) {
      setMandiOptions([]);
      return;
    }
    loadMandis();
  }, [filters.org_id, language]);

  useEffect(() => {
    loadGates(filters.mandi_id);
  }, [filters.mandi_id, language]);

  useEffect(() => {
    loadData();
  }, [
    filters.org_id,
    filters.mandi_id,
    filters.gate_code,
    filters.status,
    filters.token_type,
    filters.date_from,
    filters.date_to,
    language,
    canViewPass,
    canViewEntry,
  ]);

  const updateFilter = (key: keyof typeof filters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  if (!canViewPass && !canViewEntry) {
    return (
      <PageContainer>
        <Typography variant="h6">Not authorized to view gate tokens.</Typography>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={2} mb={2}>
        <Stack spacing={0.5}>
          <Typography variant="h5">{t("menu.gateTokens", { defaultValue: "Gate Entry Tokens" })}</Typography>
          <Typography variant="body2" color="text.secondary">
            Combined view of gate pass and entry tokens (read-only).
          </Typography>
          {isDebug && (
            <Typography variant="caption" color="text.secondary">
              canCreateEntry: {String(canCreateEntry)} | canCreatePass: {String(canCreatePass)} | canUpdateEntry: {String(canUpdateEntry)} | permKeys: {Object.keys(permissionsMap || {}).length}
            </Typography>
          )}
        </Stack>
        <Stack direction="row" spacing={1}>
          {(canCreateEntry || canCreatePass) && (
            <Button
              variant="contained"
              onClick={() => navigate("/gate-entries/create")}
            >
              Create Token
            </Button>
          )}
          <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadData} disabled={loading}>
            Refresh
          </Button>
        </Stack>
      </Stack>

      <Stack
        direction={isMobile ? "column" : "row"}
        spacing={2}
        mb={2}
        alignItems={isMobile ? "stretch" : "center"}
        flexWrap="wrap"
      >
        {uiConfig.role === "SUPER_ADMIN" && (
          <TextField
            select
            label="Organisation"
            size="small"
            sx={{ minWidth: isMobile ? "100%" : 220 }}
            fullWidth={isMobile}
            value={filters.org_id}
            onChange={(e) => updateFilter("org_id", e.target.value)}
          >
            <MenuItem value="">All</MenuItem>
            {orgOptions.map((o) => (
              <MenuItem key={o.value} value={o.value}>
                {o.label}
              </MenuItem>
            ))}
          </TextField>
        )}

        <TextField
          select
          label="Mandi"
          size="small"
          sx={{ minWidth: isMobile ? "100%" : 180 }}
          fullWidth={isMobile}
          value={filters.mandi_id}
          onChange={(e) => updateFilter("mandi_id", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          {mandiOptions.map((m) => (
            <MenuItem key={m.value} value={m.value}>
              {m.label}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          select
          label="Gate"
          size="small"
          sx={{ minWidth: isMobile ? "100%" : 160 }}
          fullWidth={isMobile}
          value={filters.gate_code}
          onChange={(e) => updateFilter("gate_code", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          {gateOptions.map((g) => (
            <MenuItem key={g.value} value={g.value}>
              {g.label}
            </MenuItem>
          ))}
        </TextField>

        {tokenTypeOptions.length > 0 && (
          <TextField
            select
            label="Token Type"
            size="small"
            sx={{ minWidth: isMobile ? "100%" : 150 }}
            fullWidth={isMobile}
            value={filters.token_type}
            onChange={(e) => updateFilter("token_type", e.target.value as any)}
          >
            {tokenTypeOptions.map((opt) => (
              <MenuItem key={opt.value} value={opt.value}>
                {opt.label}
              </MenuItem>
            ))}
          </TextField>
        )}

        <TextField
          select
          label="Status"
          size="small"
          sx={{ minWidth: isMobile ? "100%" : 150 }}
          fullWidth={isMobile}
          value={filters.status}
          onChange={(e) => updateFilter("status", e.target.value)}
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value="ISSUED">Issued</MenuItem>
          <MenuItem value="IN_YARD">In Yard</MenuItem>
          <MenuItem value="EXITED">Exited</MenuItem>
          <MenuItem value="CANCELLED">Cancelled</MenuItem>
        </TextField>

        <TextField
          label="Date From"
          type="date"
          size="small"
          fullWidth={isMobile}
          value={filters.date_from}
          onChange={(e) => updateFilter("date_from", e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <TextField
          label="Date To"
          type="date"
          size="small"
          fullWidth={isMobile}
          value={filters.date_to}
          onChange={(e) => updateFilter("date_to", e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
      </Stack>

      <Box sx={{ width: "100%" }}>
        <Typography variant="body2" color="text.secondary" mb={1}>
          Showing {rows.length} records{totalCount ? ` (server total: ${totalCount})` : ""}.
        </Typography>
        {isMobile ? (
          <Stack spacing={2}>
            {rows.map((row) => (
              <Card key={row.id || row.token_code} variant="outlined">
                <CardContent>
                  <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1}>
                    <Typography variant="subtitle1" fontWeight={600}>
                      {row.token_code || "-"}
                    </Typography>
                    <Chip
                      size="small"
                      label={row.status || "-"}
                      color={
                        row.status === "IN_YARD"
                          ? "success"
                          : row.status === "ISSUED"
                            ? "info"
                            : row.status === "EXITED"
                              ? "default"
                              : "default"
                      }
                    />
                  </Stack>
                  <Typography variant="body2" color="text.secondary">
                    Type: {row.token_type || "-"}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Vehicle: {row.vehicle_no || "-"}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Reason: {row.reason_code || "-"}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Gate: {row.gate_code || "-"} | Device: {row.device_code || "-"}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Last Step: {row.last_step || "-"}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Updated: {formatDate(row.updated_on) || "-"}
                  </Typography>
                </CardContent>
                <CardActions sx={{ justifyContent: "flex-end" }}>
                  <Button
                    size="small"
                    startIcon={<VisibilityOutlinedIcon fontSize="small" />}
                    onClick={() => navigate(`/gate-tokens/${encodeURIComponent(row.token_code)}`)}
                  >
                    View
                  </Button>
                  <Button
                    size="small"
                    onClick={() =>
                      navigate(`/gate-tokens/${encodeURIComponent(row.token_code)}#movements`)
                    }
                  >
                    Movements
                  </Button>
                </CardActions>
              </Card>
            ))}
            {rows.length === 0 && (
              <Typography variant="body2" color="text.secondary">
                No tokens found for the selected filters.
              </Typography>
            )}
          </Stack>
        ) : (
          <ResponsiveDataGrid
            rows={rows}
            columns={columns}
            loading={loading}
            getRowId={(r) => r.id || `${r.token_type}-${r.token_code}`}
            disableRowSelectionOnClick
            pageSizeOptions={[25, 50, 100]}
            initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
            minWidth={960}
          />
        )}
      </Box>
    </PageContainer>
  );
};
